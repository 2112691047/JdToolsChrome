(() => {
  'use strict';

  const TARGETS = [
    { text: '无需AI外呼', selector: 'label.jd-checkbox, label' },
    { text: '仅提醒我', selector: 'label.jd-radio, label' }
  ];

  const SCAN_INTERVAL_MS = 1500;
  const SAVE_DELAY_MS = 350;
  const RESCAN_DELAY_MS = 450;
  const SAME_FORM_COOLDOWN_MS = 8000;
  const MARKER_CLASS = 'uad-r-sample-marker';
  const MARKER_STYLE_ID = 'uad-r-sample-marker-style';
  const HIT_MARKER_CLASS = 'uad-hit-marker';
  const SMS_VALID_MARKER_CLASS = 'uad-sms-valid-marker';
  const SERVICE_LABELS = ['是否按R用户服务', '是否R用户服务', '是否按R服务', '按R服务'];
  const NON_ASSESSMENT_EVENT_SOURCES = ['网页催单', '微信投诉', '无人客服', '未知来源', '主动呼出'];
  // 事件概要命中以下任一条目则标记为不考核（使用">"分隔的多级路径，匹配时忽略空白）
  const NON_ASSESSMENT_EVENT_SUMMARIES = [
    '金融服务>其他需转接场景>转接成功',
    '金融服务>其他需转接场景>转接失败',
    '保险服务>其他需转接场景>转接成功',
    '保险服务>其他需转接场景>转接失败',
    '转接/升级>京东物流>个人外单咨询',
    '转接/升级>京东物流>商家咨询',
    '转接/升级>京东物流>上门取件',
    '转接/升级>京东物流>不送货上门',
    '转接/升级>京东物流>投诉物流相关人员',
  ];
  const PHONE_LABELS = ['绑定号码', '来电号码', '收货号码', '联系号码'];
  const QUERY_PHONE_BUTTON_CLASS = 'uad-query-phone-button';
  const REAL_PHONE_CLASS = 'uad-real-phone-marker';
  const PHONE_SILENT_CLASS = 'uad-phone-silent-query';
  const PHONE_CAPTURE_MESSAGE = '__UAD_TOOL_PHONE_CAPTURE__';

  /* -------------------- 命中状态（SMS） -------------------- */
  const HIT_STATUS_STORAGE_KEY = '__uad_hit_status_cache__';
  const HIT_STATUS_STORAGE_TTL_MS = 30 * 60 * 1000; // sessionStorage 缓存有效期 30 分钟
  // caseId → { hitStatus: 'pending'|'已命中'|'未命中'|'查询失败', smsStatus: 'pending'|'有效'|'已过期'|'无', ts: number, sendTime?, retryCount? }
  const hitStatusCache = new Map();
  const HIT_NO_CASEID = '__no_caseid__';
  let lastActiveCaseId = ''; // 当前页面事件号，用于检测事件切换
  const HIT_MAX_RETRY = 2;
  const HIT_RETRY_DELAY_MS = 3000;
  const HIT_VALID_WINDOW_MS = 5 * 24 * 3600 * 1000; // 5天有效期
  const HIT_DEBUG = false; // 调试开关，上线后改为 false

  // ---- sessionStorage 持久化 ----
  function loadHitStatusFromStorage() {
    try {
      const raw = sessionStorage.getItem(HIT_STATUS_STORAGE_KEY);
      if (!raw) return;
      const entries = JSON.parse(raw);
      if (!Array.isArray(entries)) return;
      const now = Date.now();
      for (const [key, val] of entries) {
        if (!key || !val || !val.ts) continue;
        if (now - val.ts > HIT_STATUS_STORAGE_TTL_MS) continue;
        // 兼容旧格式：将 status 迁移为 hitStatus + smsStatus
        if (val.status && !val.hitStatus) {
          if (val.status === '已命中') {
            val.hitStatus = '已命中';
            val.smsStatus = val.sendTime ? '有效' : '无';
          } else if (val.status === '已过期') {
            val.hitStatus = '未命中';
            val.smsStatus = '已过期';
          } else if (val.status === '未命中') {
            val.hitStatus = '未命中';
            val.smsStatus = '无';
          } else {
            val.hitStatus = val.status;
            val.smsStatus = '无';
          }
          delete val.status;
        }
        if (val.hitStatus === 'pending' || val.hitStatus === '查询失败') continue;
        hitStatusCache.set(key, val);
      }
    } catch (_) {}
  }

  function saveHitStatusToStorage() {
    try {
      const entries = [];
      for (const [key, val] of hitStatusCache) {
        if (val.hitStatus === 'pending') continue;
        entries.push([key, val]);
      }
      sessionStorage.setItem(HIT_STATUS_STORAGE_KEY, JSON.stringify(entries));
    } catch (_) {}
  }

  // 启动时加载持久化缓存
  loadHitStatusFromStorage();

  function getCaseIdFromCard(card) {
    if (!card) return '';

    // 0. 通过标签-值对精确提取（最可靠：只匹配当前卡片内对应标签的值，不受其他事件干扰）
    const CASEID_LABELS = ['事件号', '事件ID', '事件编号', 'caseId'];
    const caseIdByLabel = getValueByLabel(card, CASEID_LABELS);
    if (caseIdByLabel) {
      // 从标签值中提取第一个8位以上数字串（避免额外文本干扰）
      const digitMatch = caseIdByLabel.match(/(\d{8,})/);
      if (digitMatch) {
        if (HIT_DEBUG) console.log('[UAD-HIT] getCaseIdFromCard: 标签提取 caseId:', digitMatch[1], '(原始:', caseIdByLabel, ')');
        return digitMatch[1];
      }
    }

    // 1. 从卡片文本中提取事件号（降级：正则匹配，可能匹配到卡片内其他数字）
    const cardText = card.textContent || '';
    const caseIdMatch = cardText.match(/(?:事件号|事件ID|事件编号|caseId)[:\s：]*(\d{8,})/i);
    if (caseIdMatch) {
      if (HIT_DEBUG) console.log('[UAD-HIT] getCaseIdFromCard: 文本正则提取 caseId:', caseIdMatch[1]);
      return caseIdMatch[1];
    }

    // 2. 从卡片内部属性提取（仅查找卡片内部，不向上查找父容器）
    const carrier = card.querySelector('[caseid]');
    if (carrier) {
      if (HIT_DEBUG) console.log('[UAD-HIT] getCaseIdFromCard: [caseid]属性提取 caseId:', carrier.getAttribute('caseid'));
      return carrier.getAttribute('caseid') || '';
    }
    const dataCarrier = card.querySelector('[data-caseid]');
    if (dataCarrier) {
      if (HIT_DEBUG) console.log('[UAD-HIT] getCaseIdFromCard: [data-caseid]属性提取 caseId:', dataCarrier.getAttribute('data-caseid'));
      return dataCarrier.getAttribute('data-caseid') || '';
    }

    // 3. 从卡片自身的 caseid 属性
    if (card.hasAttribute('caseid')) {
      if (HIT_DEBUG) console.log('[UAD-HIT] getCaseIdFromCard: 卡片caseid属性提取 caseId:', card.getAttribute('caseid'));
      return card.getAttribute('caseid') || '';
    }
    if (card.hasAttribute('data-caseid')) {
      if (HIT_DEBUG) console.log('[UAD-HIT] getCaseIdFromCard: 卡片data-caseid属性提取 caseId:', card.getAttribute('data-caseid'));
      return card.getAttribute('data-caseid') || '';
    }

    if (HIT_DEBUG) console.log('[UAD-HIT] getCaseIdFromCard: 未能提取 caseId, card:', card ? card.tagName : 'null', card ? card.className : '');
    return '';
  }

  /* ---- 命中检测常量 ---- */
  const HIT_SMS_QUERY_URL = 'https://sms.jd.com/sms-query.html';
  const HIT_SMS_SENDER_ID = 115;
  const HIT_SMS_CONTENT_KEYWORDS = ['尊敬的', '呦'];
  const HIT_SMS_WINDOW_DAYS = 30;
  const HIT_QUERY_TIMEOUT_MS = 25000;
  const HIT_ACCOUNT_LABELS = ['客户账户', '客户账号', '客户帐号', '用户账号', '用户帐号', '用户pin', '客户pin', 'PIN', 'pin'];

  /* ---- 从 getCaseResource 响应中提取手机号 ---- */
  function extractPhoneFromCaseResponse(rawText) {
    if (!rawText) return '';
    let parsed = null;
    try {
      parsed = typeof rawText === 'string' ? JSON.parse(rawText) : rawText;
      if (parsed && typeof parsed.data === 'string') {
        try { parsed.data = JSON.parse(parsed.data); } catch (_e) { /* keep string */ }
      }
    } catch (_e) { parsed = null; }

    const findKey = (obj, target) => {
      if (obj == null) return null;
      if (typeof obj === 'string') {
        const m = obj.match(new RegExp('[?&]' + target + '=([\\d\\*\\-]+)'));
        return m ? m[1] : null;
      }
      if (typeof obj !== 'object') return null;
      if (obj[target]) return obj[target];
      for (const k of Object.keys(obj)) {
        const v = findKey(obj[k], target);
        if (v) return v;
      }
      return null;
    };

    if (parsed) {
      const candidate = findKey(parsed.data || parsed, 'callTel');
      if (candidate) return String(candidate).replace(/[^\d]/g, '');
    }
    const cleanRaw = String(rawText).replace(/\\/g, '');
    const m = cleanRaw.match(/"callTel"\s*:\s*"?([\d\*\-]+)"?/)
      || cleanRaw.match(/[?&]callTel=([\d\*\-]+)/)
      || cleanRaw.match(/callTel[^\w]([\d\*\-]+)/);
    return m ? m[1].replace(/[^\d]/g, '') : '';
  }

  /* ---- 从 getCaseResource 响应中提取客户 pin ---- */
  function extractPinFromCaseResponse(rawText) {
    if (!rawText) return '';
    let parsed = null;
    try {
      parsed = typeof rawText === 'string' ? JSON.parse(rawText) : rawText;
      if (parsed && typeof parsed.data === 'string') {
        try { parsed.data = JSON.parse(parsed.data); } catch (_e) { /* keep string */ }
      }
    } catch (_e) { parsed = null; }

    const findKey = (obj, target) => {
      if (obj == null) return null;
      if (typeof obj === 'string') return null;
      if (typeof obj !== 'object') return null;
      if (obj[target]) return obj[target];
      for (const k of Object.keys(obj)) {
        const v = findKey(obj[k], target);
        if (v) return v;
      }
      return null;
    };

    const pinKeys = ['customerPin', 'pin', 'customerAccount', 'account', 'userPin', 'customerName'];
    if (parsed) {
      for (const key of pinKeys) {
        const val = findKey(parsed.data || parsed, key);
        if (val && typeof val === 'string' && val.trim()) return val.trim();
      }
    }
    return '';
  }

  /* ---- 从卡片 DOM 中提取客户账户 ---- */
  function getAccountFromCard(card) {
    if (!card) return '';
    return getValueByLabel(card, HIT_ACCOUNT_LABELS) || '';
  }

  /* ---- 从卡片 DOM 中提取手机号（降级方案） ---- */
  function getPhoneFromCard(card) {
    if (!card) return '';
    const value = getValueByLabel(card, PHONE_LABELS);
    if (!value) return '';
    // 提取纯数字手机号（支持带星号脱敏格式如 138****1234）
    const digits = value.replace(/[^\d*]/g, '');
    if (digits.length >= 11) return digits;
    return '';
  }

  /* ---- 查询 sms.jd.com 判断是否已发 115 短信 ---- */
  async function querySmsHitStatus(phone) {
    if (!phone || phone.length < 11) return { hit: false, sendTime: null };
    const now = new Date();
    const start = new Date(now.getTime() - HIT_SMS_WINDOW_DAYS * 24 * 3600 * 1000);
    const pad = n => String(n).padStart(2, '0');
    const startTime = `${start.getFullYear()}-${pad(start.getMonth() + 1)}-${pad(start.getDate())} ${pad(start.getHours())}:${pad(start.getMinutes())}:${pad(start.getSeconds())}`;
    const endTime = `${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())} ${pad(now.getHours())}:${pad(now.getMinutes())}:${pad(now.getSeconds())}`;

    const body = JSON.stringify({
      mobileNum: phone, startTime, endTime,
      keyword: '', senderSource: 0, pageNo: 1, pageSize: 50
    });

    try {
      const resp = await new Promise((resolve, reject) => {
        if (typeof chrome === 'undefined' || !chrome.runtime || typeof chrome.runtime.sendMessage !== 'function') {
          reject(new Error('扩展通信不可用')); return;
        }
        chrome.runtime.sendMessage(
          { type: 'JD_SMS_TOOL_FETCH_TEXT', url: HIT_SMS_QUERY_URL,
            options: { method: 'POST', headers: { 'Content-Type': 'application/json;charset=UTF-8', 'Accept': 'application/json, text/plain, */*' }, body, credentials: 'include', timeoutMs: 15000 } },
          (response) => {
            const err = chrome.runtime && chrome.runtime.lastError;
            if (err) { reject(new Error(err.message)); return; }
            resolve(response);
          }
        );
      });

      if (!resp || !resp.ok) return { hit: false, sendTime: null };
      const json = JSON.parse(resp.text || '{}');
      const result = json && json.result ? json.result : { records: [] };
      const records = Array.isArray(result.records) ? result.records : [];
      let matchedRecord = null;
      const hit = records.some(item => {
        const senderId = Number(item && item.senderId);
        if (senderId !== HIT_SMS_SENDER_ID) return false;
        const content = String(item && item.smsContent || '');
        const isMatch = HIT_SMS_CONTENT_KEYWORDS.every(k => content.includes(k));
        if (isMatch) { matchedRecord = item; }
        return isMatch;
      });
      const sendTime = matchedRecord && matchedRecord.sendTime ? matchedRecord.sendTime : null;
      return { hit, sendTime };
    } catch (_) { return { hit: false, sendTime: null }; }
  }

  /* ---- queryBeanHitStatus 已移除（不再使用京豆查询） ---- */

  /* ---- 命中状态主查询 ---- */
  function queryCaseHitStatus(caseId, card, forceRefresh) {
    if (!caseId) return;
    const cached = hitStatusCache.get(caseId);
    // 有缓存且非pending且非强制刷新且非查询失败 → 不再查询
    // 查询失败允许重试（可能是临时网络问题）
    if (!forceRefresh && cached && cached.hitStatus !== 'pending' && cached.hitStatus !== '查询失败') return;

    if (HIT_DEBUG) console.log('[UAD-HIT] queryCaseHitStatus: 开始查询 caseId:', caseId, 'forceRefresh:', !!forceRefresh);
    hitStatusCache.set(caseId, { hitStatus: 'pending', smsStatus: 'pending', ts: Date.now() });

    const queryId = 'uad_hit_' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 8);
    const timer = setTimeout(() => {
      window.removeEventListener('message', onCaseResponse);
      const cur = hitStatusCache.get(caseId);
      if (cur && cur.hitStatus === 'pending') {
        // 超时时自动重试
        const retryCount = (cur && cur.retryCount) || 0;
        if (retryCount < HIT_MAX_RETRY) {
          hitStatusCache.set(caseId, { hitStatus: 'pending', smsStatus: 'pending', ts: Date.now(), retryCount: retryCount + 1 });
          setTimeout(() => queryCaseHitStatus(caseId, card, true), HIT_RETRY_DELAY_MS);
        } else {
          hitStatusCache.set(caseId, { hitStatus: '查询失败', smsStatus: '无', ts: Date.now() });
        }
        scheduleScan();
      }
    }, HIT_QUERY_TIMEOUT_MS);

    const onCaseResponse = async (event) => {
      if (event.source !== window || !event.data) return;
      if (event.data.type !== 'JD_SMS_QUERY_CASE_RESPONSE' || event.data.queryId !== queryId) return;
      clearTimeout(timer);
      window.removeEventListener('message', onCaseResponse);

      if (HIT_DEBUG) console.log('[UAD-HIT] onCaseResponse: 收到响应 caseId:', caseId, 'success:', event.data.success);

      // 1. 从 getCaseResource 响应提取手机号和客户 pin
      let phone = '';
      let pin = '';
      try {
        if (event.data.success && event.data.data) {
          const rawText = typeof event.data.data === 'string' ? event.data.data : JSON.stringify(event.data.data);
          phone = extractPhoneFromCaseResponse(rawText);
          pin = extractPinFromCaseResponse(rawText);
        }
      } catch (_) {}

      // 2. 从卡片 DOM 补充提取客户 pin 和手机号（降级方案）
      if (!pin) {
        try { pin = getAccountFromCard(card); } catch (_) {}
      }
      if (!phone) {
        try { phone = getPhoneFromCard(card); } catch (_) {}
      }

      if (HIT_DEBUG) console.log('[UAD-HIT] onCaseResponse: caseId:', caseId, 'phone:', phone || '(空)', 'pin:', pin || '(空)');

      // 3. 查询 SMS 短信命中状态（仅根据SMS判断命中和时效）
      try {
        const smsResult = phone ? await querySmsHitStatus(phone) : { hit: false, sendTime: null };

        if (HIT_DEBUG) console.log('[UAD-HIT] onCaseResponse: SMS查询结果 caseId:', caseId, 'hit:', smsResult.hit, 'sendTime:', smsResult.sendTime);

        // 命中状态和SMS时效状态均仅根据短信发送时间判断
        let hitStatus = '未命中';
        let smsStatus = '无';
        let sendTime = null;

        if (smsResult.hit && smsResult.sendTime) {
          sendTime = smsResult.sendTime;
          const sendMs = new Date(sendTime).getTime();
          const deadline = sendMs + HIT_VALID_WINDOW_MS;
          if (Date.now() <= deadline) {
            hitStatus = '已命中';
            smsStatus = '有效';
          } else {
            hitStatus = '未命中';
            smsStatus = '已过期';
          }
        } else if (smsResult.hit) {
          // SMS命中但无时间信息，视为已命中但无时效
          hitStatus = '已命中';
          smsStatus = '无';
        }
        // 未命中时 hitStatus='未命中', smsStatus='无' — 扫描时不显示标记

        if (HIT_DEBUG) console.log('[UAD-HIT] onCaseResponse: 最终结果 caseId:', caseId, 'hitStatus:', hitStatus, 'smsStatus:', smsStatus, 'sendTime:', sendTime);

        hitStatusCache.set(caseId, { hitStatus, smsStatus, ts: Date.now(), sendTime });
        saveHitStatusToStorage();
      } catch (_) {
        // 查询失败时自动重试
        const cur = hitStatusCache.get(caseId);
        const retryCount = (cur && cur.retryCount) || 0;
        if (HIT_DEBUG) console.log('[UAD-HIT] onCaseResponse: 查询异常 caseId:', caseId, 'retryCount:', retryCount);
        if (retryCount < HIT_MAX_RETRY) {
          hitStatusCache.set(caseId, { hitStatus: 'pending', smsStatus: 'pending', ts: Date.now(), retryCount: retryCount + 1 });
          setTimeout(() => queryCaseHitStatus(caseId, card, true), HIT_RETRY_DELAY_MS);
        } else {
          hitStatusCache.set(caseId, { hitStatus: '查询失败', smsStatus: '无', ts: Date.now() });
        }
      }
      scheduleScan();
    };

    window.addEventListener('message', onCaseResponse);
    window.postMessage({ type: 'JD_SMS_QUERY_CASE_REQUEST', queryId, caseId: String(caseId) }, '*');
  }


  // 优先在页面上下文发起请求（与页面自身请求保持同源 Cookie/Referer），失败再回退到 background。
  function uadPageFetch(url, options = {}) {
    return new Promise((resolve, reject) => {
      const id = `uad_pf_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
      const timeout = window.setTimeout(() => {
        window.removeEventListener('message', onMessage);
        reject(new Error('页面请求超时'));
      }, 10000);

      const onMessage = (event) => {
        const data = event && event.data;
        if (event.source !== window || !data || data.type !== '__UAD_PAGE_FETCH_RES__' || data.id !== id) return;
        clearTimeout(timeout);
        window.removeEventListener('message', onMessage);
        resolve({ ok: !!data.ok, status: Number(data.status) || 0, text: String(data.text || ''), error: data.error || '' });
      };

      window.addEventListener('message', onMessage);

      const payload = {
        id,
        type: '__UAD_PAGE_FETCH_REQ__',
        url,
        method: options.method || 'POST',
        headers: options.headers || {},
        body: options.body || null
      };

      const script = document.createElement('script');
      script.textContent = `(() => {
        const req = ${JSON.stringify(payload)};
        const done = (res) => window.postMessage(Object.assign({ type: '__UAD_PAGE_FETCH_RES__', id: req.id }, res), '*');
        fetch(req.url, {
          method: req.method,
          headers: req.headers || {},
          body: req.body || null,
          credentials: 'include'
        })
          .then(async (resp) => {
            const text = await resp.text();
            done({ ok: resp.ok, status: resp.status, text });
          })
          .catch((err) => {
            done({ ok: false, status: 0, text: '', error: err && err.message ? err.message : String(err) });
          });
      })();`;

      (document.documentElement || document.head || document.body).appendChild(script);
      script.remove();
    });
  }

  function uadBackgroundFetch(url, options = {}) {
    const method = options.method || 'POST';
    const headers = options.headers || {};
    const body = options.body || null;

    return new Promise((resolve, reject) => {
      if (
        typeof chrome === 'undefined' ||
        !chrome.runtime ||
        typeof chrome.runtime.sendMessage !== 'function'
      ) {
        reject(new Error('扩展通信不可用，请刷新页面并重新加载扩展'));
        return;
      }

      try {
        chrome.runtime.sendMessage(
          { type: 'UAD_FETCH', url, method, headers, body },
          (response) => {
            const runtimeError = chrome.runtime && chrome.runtime.lastError;
            if (runtimeError) {
              reject(new Error(runtimeError.message));
              return;
            }
            if (!response) {
              reject(new Error('background 无响应'));
              return;
            }
            resolve(response);
          }
        );
      } catch (e) {
        reject(e);
      }
    });
  }

  // content script 直接发起 fetch（同源时能自动携带 Cookie）
  async function uadDirectFetch(url, options = {}) {
    const method = options.method || 'POST';
    const headers = options.headers || {};
    const body = options.body || null;
    const resp = await fetch(url, { method, headers, body, credentials: 'include' });
    const text = await resp.text();
    return { ok: resp.ok, status: resp.status, text };
  }

  async function uadFetch(url, options = {}) {
    const method = options.method || 'POST';
    const headers = options.headers || {};
    const body = options.body || null;

    try {
      const target = new URL(url, location.href);
      if (target.origin === location.origin) {
        // 优先：content script 直接 fetch（同源自动带 Cookie）
        try {
          return await uadDirectFetch(target.toString(), { method, headers, body });
        } catch (_) {}
        // 次选：注入页面主世界 script 发请求
        try {
          return await uadPageFetch(target.toString(), { method, headers, body });
        } catch (_) {}
      }
    } catch (_) {}

    return uadBackgroundFetch(url, { method, headers, body });
  }

  const pendingSaveContainers = new WeakSet();
  const recentSaveByKey = new Map();
  let scanTimer = 0;

  function normalizeText(value) {
    return String(value || '').replace(/\s+/g, '').replace(/\u00a0/g, '').trim();
  }

  function cleanLabelText(value) {
    return normalizeText(value).replace(/[：:]+$/g, '');
  }

  function isConnectedElement(el) {
    return el && el.nodeType === 1 && document.documentElement.contains(el);
  }

  function isDisabled(el) {
    if (!el) return true;
    if (el.disabled) return true;
    if (el.getAttribute('aria-disabled') === 'true') return true;
    if (el.classList && el.classList.contains('is-disabled')) return true;
    return false;
  }

  function hasText(el, text) {
    return normalizeText(el && el.textContent).includes(normalizeText(text));
  }

  function clickLikeUser(el) {
    if (!el) return;
    try {
      el.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, cancelable: true, view: window }));
      el.dispatchEvent(new MouseEvent('mouseup', { bubbles: true, cancelable: true, view: window }));
      el.click();
    } catch (_) {
      try { el.click(); } catch (__) {}
    }
  }

  function fireNativeEvents(input) {
    if (!input) return;
    input.dispatchEvent(new Event('input', { bubbles: true }));
    input.dispatchEvent(new Event('change', { bubbles: true }));
  }

  /* -------------------- 跟单动作自动修正 -------------------- */

  function getSmartFollowContainers() {
    const containers = new Set();

    document.querySelectorAll('.auto-follow-close').forEach((el) => {
      if (hasText(el, '智能跟关单') && hasText(el, '修改')) containers.add(el);
    });

    document.querySelectorAll('form, [role="tooltip"], .jd-popover, .follow-content').forEach((el) => {
      if (hasText(el, '智能跟关单') && hasText(el, '修改')) {
        containers.add(el.closest('.auto-follow-close') || el);
      }
    });

    return Array.from(containers).filter(isConnectedElement);
  }

  function findLabelByText(container, target) {
    const labels = Array.from(container.querySelectorAll(target.selector));
    return labels.find((label) => normalizeText(label.textContent) === normalizeText(target.text));
  }

  function getInputFromLabel(label) {
    if (!label) return null;
    return label.querySelector('input[type="checkbox"], input[type="radio"]');
  }

  function isChecked(label, input) {
    if (!label) return false;
    if (input && input.checked) return true;
    if (label.classList.contains('is-checked')) return true;
    if (label.querySelector('.is-checked')) return true;
    if (input && input.getAttribute('aria-checked') === 'true') return true;
    return false;
  }

  function ensureChecked(container, target) {
    const label = findLabelByText(container, target);
    if (!label) return false;

    const input = getInputFromLabel(label);
    if (isDisabled(input) || isDisabled(label)) return false;
    if (isChecked(label, input)) return false;

    clickLikeUser(label);

    if (input && !input.checked) {
      input.checked = true;
      fireNativeEvents(input);
    } else {
      fireNativeEvents(input);
    }

    return true;
  }

  function findModifyButton(container) {
    const buttons = Array.from(container.querySelectorAll('button'));
    return buttons.find((button) => !isDisabled(button) && normalizeText(button.textContent) === '修改');
  }

  function getContainerKey(container) {
    const text = normalizeText(container.textContent).slice(0, 500);
    return text || String(Date.now());
  }

  function canSave(container) {
    const key = getContainerKey(container);
    const last = recentSaveByKey.get(key) || 0;
    if (Date.now() - last < SAME_FORM_COOLDOWN_MS) return false;
    recentSaveByKey.set(key, Date.now());
    return true;
  }

  function scheduleSave(container) {
    if (!isConnectedElement(container)) return;
    if (pendingSaveContainers.has(container)) return;
    if (!canSave(container)) return;

    pendingSaveContainers.add(container);
    window.setTimeout(() => {
      try {
        const button = findModifyButton(container);
        if (button) clickLikeUser(button);
      } finally {
        pendingSaveContainers.delete(container);
        window.setTimeout(scheduleScan, RESCAN_DELAY_MS);
      }
    }, SAVE_DELAY_MS);
  }

  function scanSmartFollowOnce() {
    const containers = getSmartFollowContainers();
    containers.forEach((container) => {
      let changed = false;

      for (const target of TARGETS) {
        if (ensureChecked(container, target)) changed = true;
      }

      if (changed) scheduleSave(container);
    });
  }

  /* -------------------- 考核 / 不考核标记 -------------------- */

  function injectMarkerStyle() {
    if (document.getElementById(MARKER_STYLE_ID)) return;
    const style = document.createElement('style');
    style.id = MARKER_STYLE_ID;
    style.textContent = `
      .${MARKER_CLASS} {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        min-width: 42px;
        height: 22px;
        padding: 0 8px;
        margin-right: 8px;
        border-radius: 4px;
        font-size: 12px;
        font-weight: 600;
        line-height: 22px;
        box-sizing: border-box;
        vertical-align: middle;
        user-select: none;
      }
      .${MARKER_CLASS}.is-check {
        color: #d93026;
        border: 1px solid #f3b6b2;
        background: #fff1f0;
      }
      .${MARKER_CLASS}.is-no-check {
        color: #147a3c;
        border: 1px solid #a7dfbd;
        background: #f0fff5;
      }

      .${QUERY_PHONE_BUTTON_CLASS} {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        height: 22px;
        padding: 0 8px;
        margin-right: 8px;
        border-radius: 4px;
        font-size: 12px;
        font-weight: 600;
        line-height: 22px;
        box-sizing: border-box;
        vertical-align: middle;
        user-select: none;
        cursor: pointer;
        color: #1a73e8;
        border: 1px solid #b8d7ff;
        background: #f3f8ff;
      }
      .${QUERY_PHONE_BUTTON_CLASS}.is-loading {
        cursor: default;
        color: #8a6d1d;
        border-color: #f0d98c;
        background: #fff8db;
      }
      .${QUERY_PHONE_BUTTON_CLASS}.is-done {
        color: #147a3c;
        border-color: #a7dfbd;
        background: #f0fff5;
      }
      .${QUERY_PHONE_BUTTON_CLASS}.is-error {
        color: #d93026;
        border-color: #f3b6b2;
        background: #fff1f0;
      }
      .${REAL_PHONE_CLASS} {
        display: inline-flex;
        align-items: center;
        min-width: 62px;
        height: 18px;
        padding: 0 5px;
        margin-left: 6px;
        border-radius: 3px;
        font-size: 12px;
        font-weight: 600;
        line-height: 18px;
        color: #1a73e8;
        border: 1px solid #b8d7ff;
        background: #f3f8ff;
        box-sizing: border-box;
        vertical-align: middle;
        user-select: text;
      }
      .${REAL_PHONE_CLASS}.is-loading {
        color: #8a6d1d;
        border-color: #f0d98c;
        background: #fff8db;
      }
      .${REAL_PHONE_CLASS}.is-error {
        color: #d93026;
        border-color: #f3b6b2;
        background: #fff1f0;
      }
      html.${PHONE_SILENT_CLASS} .jd-dialog-modal,
      html.${PHONE_SILENT_CLASS} .jd-overlay-dialog,
      html.${PHONE_SILENT_CLASS} iframe[src*="/plugin/biz/caseInfo/prepareCreate"] {
        opacity: 0 !important;
        pointer-events: none !important;
      }

      .${HIT_MARKER_CLASS} {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        min-width: 48px;
        height: 22px;
        padding: 0 8px;
        margin-left: 8px;
        border-radius: 4px;
        font-size: 12px;
        font-weight: 600;
        line-height: 22px;
        box-sizing: border-box;
        vertical-align: middle;
        user-select: none;
        cursor: pointer;
      }
      .${HIT_MARKER_CLASS}.is-hit {
        color: #147a3c;
        border: 1px solid #a7dfbd;
        background: #f0fff5;
      }
      .${HIT_MARKER_CLASS}.is-no-hit {
        color: #d93026;
        border: 1px solid #f3b6b2;
        background: #fff1f0;
      }
      .${HIT_MARKER_CLASS}.is-loading {
        color: #8a6d1d;
        border: 1px solid #f0d98c;
        background: #fff8db;
      }
      .${HIT_MARKER_CLASS}.is-error {
        color: #856404;
        border: 1px solid #ffc107;
        background: #fff3cd;
        cursor: pointer;
      }
      .${SMS_VALID_MARKER_CLASS} {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        min-width: 48px;
        height: 22px;
        padding: 0 8px;
        margin-left: 4px;
        margin-right: 12px;
        border-radius: 4px;
        font-size: 12px;
        font-weight: 600;
        line-height: 22px;
        box-sizing: border-box;
        vertical-align: middle;
        user-select: none;
      }
      .${SMS_VALID_MARKER_CLASS}.is-valid {
        color: #1a73e8;
        border: 1px solid #b8d7ff;
        background: #f3f8ff;
      }
      .${SMS_VALID_MARKER_CLASS}.is-expired {
        color: #856404;
        border: 1px solid #ffc107;
        background: #fff3cd;
      }
    `;
    document.documentElement.appendChild(style);
  }

  function isProcessEventButton(button) {
    if (!button || button.tagName !== 'BUTTON') return false;
    const text = normalizeText(button.textContent);
    const heatmap = button.getAttribute('data-heatmap-tagcls') || '';
    return text === '处理此事件' || heatmap.includes('EVENT_INFO|CLICK_CASE_OPERATE');
  }

  function getEventCardFromButton(button) {
    // 策略：从按钮向上查找最小的、只包含本按钮对应事件的容器
    // 优先使用最具体的选择器，但需验证容器内只有一个"处理此事件"按钮
    const specificCard = button.closest('.u-detail-row-block.lg-card');
    if (specificCard) {
      const btns = Array.from(specificCard.querySelectorAll('button')).filter(isProcessEventButton);
      if (btns.length <= 1) return specificCard;
    }

    // 逐级向上查找：找到包含表单标签且只含一个"处理此事件"按钮的最小容器
    let el = button.parentElement;
    while (el && el !== document.body && el !== document.documentElement) {
      const hasLabels = el.querySelector('.lg-form-label, .jd-form-item__label, label, [class*="form-label"]');
      if (hasLabels) {
        const btns = Array.from(el.querySelectorAll('button')).filter(isProcessEventButton);
        if (btns.length <= 1) return el;
        // 包含多个"处理此事件"按钮说明容器过大，停止向上查找
        break;
      }
      el = el.parentElement;
    }

    // 降级：使用原始选择器
    return button.closest('.lg-card') ||
      button.closest('.summary-detail-content') ||
      button.parentElement;
  }

  function getValueByLabel(root, labelNames) {
    if (!root) return '';
    const wanted = labelNames.map(cleanLabelText);
    const labelCandidates = Array.from(root.querySelectorAll('.lg-form-label, .jd-form-item__label, label, [class*="form-label"], [class*="label-inline"]'));

    for (const label of labelCandidates) {
      const labelText = cleanLabelText(label.textContent);
      if (!labelText) continue;
      const matched = wanted.some((name) => labelText === name || labelText.includes(name));
      if (!matched) continue;

      let content = label.parentElement && label.parentElement.querySelector('.lg-form-content, .jd-form-item__content, [class*="form-content"]');
      if (content && content !== label) return content.textContent.trim();

      const next = label.nextElementSibling;
      if (next) return next.textContent.trim();

      const parentText = label.parentElement ? label.parentElement.textContent : '';
      const reg = new RegExp(label.textContent.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '\\s*([是否])');
      const m = parentText.match(reg);
      if (m) return m[1];
    }

    return '';
  }

  function getValueByTextFallback(root, labelName) {
    const raw = String(root && root.textContent || '');
    const plainLabel = String(labelName).replace(/[：:]+$/g, '');
    const escaped = plainLabel.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const reg = new RegExp(escaped + '\\s*[：:]?\\s*(是|否)');
    const m = raw.match(reg);
    return m ? m[1] : '';
  }

  function parseYesNo(value) {
    const text = normalizeText(value);
    if (!text) return null;
    if (/^(否|不是|无|没有|未|不)$/u.test(text)) return 'no';
    if (/^(是|已是|有)$/u.test(text)) return 'yes';
    if (text.includes('否') || text.includes('不是') || text.includes('没有') || text.includes('未')) return 'no';
    if (text.includes('是')) return 'yes';
    return null;
  }

  function parseServiceStatusFromText(value) {
    const text = normalizeText(value);
    if (!text || text === '事件未打标' || text === '-' || text === '无') return 'missing';

    // 明确字段值优先。
    const direct = text.match(/(?:是否按R用户服务|是否R用户服务|是否按R服务|按R服务)[:：-]?(是|否)/u);
    if (direct) return direct[1] === '是' ? 'yes' : 'no';

    // 负向表达优先，避免“不按R服务”被误判为“按R服务”。
    if (/不按R服务|未按R服务|无需按R服务|非R服务|无R服务|没有按R服务|否按R服务/u.test(text)) {
      return 'no';
    }

    if (/按R服务|R服务/u.test(text)) return 'yes';

    return 'missing';
  }

  function getServiceStatus(card) {
    for (const label of SERVICE_LABELS) {
      const directValue = getValueByLabel(card, [label]);
      const direct = parseYesNo(directValue);
      if (direct) return direct;

      const directFallback = getValueByTextFallback(card, label);
      const directFallbackParsed = parseYesNo(directFallback);
      if (directFallbackParsed) return directFallbackParsed;
    }

    const serviceTag = getValueByLabel(card, ['服务标签']);
    return parseServiceStatusFromText(serviceTag);
  }

  function getCreatedRStatus(card) {
    const value = getValueByLabel(card, ['创建事件时是否R用户', '创建时是否R', '是否R用户']);
    const parsed = parseYesNo(value);
    if (parsed) return parsed;

    const fallback = getValueByTextFallback(card, '创建事件时是否R用户');
    return parseYesNo(fallback);
  }

  function normalizeEventSource(value) {
    const text = normalizeText(value);
    if (!text) return '';
    return NON_ASSESSMENT_EVENT_SOURCES.find((source) => text.includes(normalizeText(source))) || '';
  }

  function getEventSource(card) {
    const directValue = getValueByLabel(card, ['事件来源', '来源']);
    const direct = normalizeEventSource(directValue);
    if (direct) return direct;

    const raw = String(card && card.textContent || '');
    const labelMatched = raw.match(/事件来源\s*[：:]?\s*([^\s\n\r，,;；]+)/u);
    const fromLabel = normalizeEventSource(labelMatched && labelMatched[1]);
    if (fromLabel) return fromLabel;

    return normalizeEventSource(raw);
  }

  function getEventSummary(card) {
    // 优先通过标签字段读取事件概要
    const direct = getValueByLabel(card, ['事件概要', '概要']);
    if (direct) return normalizeText(direct);

    // 降级：从卡片文本中正则匹配
    const raw = String(card && card.textContent || '');
    const m = raw.match(/事件概要\s*[：:]?\s*([^\n\r]{1,100})/u);
    return m ? normalizeText(m[1]) : '';
  }

  function matchesNonAssessmentSummary(summary) {
    if (!summary) return false;
    // 将待匹配字符串与规则列表逐一比对（忽略空白后完全相等）
    return NON_ASSESSMENT_EVENT_SUMMARIES.some(
      (rule) => normalizeText(rule) === summary
    );
  }

  function judgeResult(createdR, serviceStatus, eventSource, eventSummary) {
    if (NON_ASSESSMENT_EVENT_SOURCES.includes(eventSource)) return '不考核';
    if (matchesNonAssessmentSummary(eventSummary)) return '不考核';
    // createdR 无法识别时不再返回 null（会导致标记被移除），改为由后续逻辑默认'考核'

    // 规则来源于用户提供的表格：
    // 1 是 + 是 => 不考核
    // 2 是 + 否 => 考核
    // 3 是 + 无“是否按R服务”字段 => 不考核
    // 4 否 + 是 => 不考核
    // 5 否 + 否 => 考核
    // 6 否 + 无“是否按R服务”字段 => 考核
    // serviceStatus 为 yes/no 时不需要 createdR 即可判断，优先检查
    if (serviceStatus === 'yes') return '不考核';
    if (serviceStatus === 'no') return '考核';

    // serviceStatus 为 missing 时需要 createdR 判断
    if (serviceStatus === 'missing') {
      if (createdR === 'yes') return '不考核';
      // createdR 为 'no' 或无法识别时，默认返回'考核'（保守策略）
      return '考核';
    }

    // serviceStatus 也无法确定时，默认返回'考核'（保守策略：宁可多标考核也不漏标）
    return '考核';
  }

  function markerTitle(createdR, serviceStatus, result, eventSource, eventSummary) {
    const rText = createdR === 'yes' ? '是' : createdR === 'no' ? '否' : '未识别';
    const serviceText = serviceStatus === 'yes' ? '是' : serviceStatus === 'no' ? '否' : '事件单中未识别到“是否按R服务”字段';
    const sourceText = eventSource || '未识别';
    const sourceRuleText = NON_ASSESSMENT_EVENT_SOURCES.includes(eventSource) ? '命中事件来源不考核规则' : '未命中事件来源不考核规则';
    const summaryText = eventSummary || '未识别';
    const summaryRuleText = matchesNonAssessmentSummary(eventSummary) ? '命中事件概要不考核规则' : '未命中事件概要不考核规则';
    return `uad工具判断：${result}；事件来源：${sourceText}；${sourceRuleText}；事件概要：${summaryText}；${summaryRuleText}；创建事件时是否R用户：${rText}；是否按R用户服务/是否按R服务：${serviceText}`;
  }



  /* -------------------- 按需查询真实手机号 -------------------- */

  const realPhoneCache = new Map();
  const realPhonePending = new Map();
  let activePhoneCapture = null;

  function removeOwnText(value) {
    return String(value || '')
      .replace(/查询手机号码|查询中|已查询|未识别|读取失败/g, '')
      .replace(/\s+/g, ' ');
  }

  function findFullPhones(value) {
    const text = String(value || '');
    const found = text.match(/(?<!\d)1[3-9]\d{9}(?!\d)/g) || [];
    return Array.from(new Set(found));
  }

  function cleanFullPhone(value) {
    const text = String(value || '');
    const direct = findFullPhones(text)[0];
    if (direct) return direct;
    const digits = text.replace(/\D/g, '');
    return /^1[3-9]\d{9}$/.test(digits) ? digits : '';
  }

  function findMaskedPhone(value) {
    const text = String(value || '').replace(/\s+/g, '');
    const matched = text.match(/1[3-9]\d{0,2}\*{2,}\d{3,4}/u);
    return matched ? matched[0] : '';
  }

  function matchesMaskedPhone(phone, masked) {
    const full = cleanFullPhone(phone);
    const mask = String(masked || '').replace(/\s+/g, '');
    if (!full || !mask || !mask.includes('*')) return false;
    const parts = mask.match(/^(\d{2,4})\*+(\d{3,4})$/u);
    if (!parts) return false;
    return full.startsWith(parts[1]) && full.endsWith(parts[2]);
  }

  function parsePhoneFromUrl(value) {
    try {
      const url = new URL(String(value || ''), window.location.href);
      return cleanFullPhone(url.searchParams.get('clueVal') || url.searchParams.get('caseValue') || '');
    } catch (_) {
      return '';
    }
  }

  function readCreateFormPhoneFromDocument(doc, frameHref) {
    try {
      const input = doc && doc.querySelector && doc.querySelector('#caseClueValueShow, input[name="clueValShow"], input[name="clueVal"], input[id*="ClueValue"], input[id*="clueVal"]');
      const fromInput = cleanFullPhone(input && (input.value || input.getAttribute('value') || input.textContent));
      if (fromInput) return fromInput;
    } catch (_) {}

    const fromHref = parsePhoneFromUrl(frameHref || '');
    if (fromHref) return fromHref;

    try {
      const text = String(doc && doc.body && doc.body.textContent || '');
      return findFullPhones(text)[0] || '';
    } catch (_) {
      return '';
    }
  }

  function readCreateFormPhoneFromAnyFrame() {
    const current = readCreateFormPhoneFromDocument(document, window.location.href);
    if (current) return current;

    const frames = Array.from(document.querySelectorAll('iframe'));
    for (const frame of frames) {
      const fromSrc = parsePhoneFromUrl(frame.getAttribute('src') || '');
      if (fromSrc) return fromSrc;
      try {
        const doc = frame.contentDocument || (frame.contentWindow && frame.contentWindow.document);
        const phone = readCreateFormPhoneFromDocument(doc, frame.contentWindow && frame.contentWindow.location && frame.contentWindow.location.href);
        if (phone) return phone;
      } catch (_) {}
    }
    return '';
  }

  function maybeResolveActivePhoneCapture(phone) {
    if (!activePhoneCapture) return false;
    const full = cleanFullPhone(phone);
    if (!full) return false;
    if (activePhoneCapture.masked && !matchesMaskedPhone(full, activePhoneCapture.masked)) return false;
    activePhoneCapture.resolve(full);
    return true;
  }

  function startCreateFrameNotifier() {
    // 创建事件页面可能在 iframe 中打开；all_frames=true 时这里负责把输入框里的真实手机号发给主页面。
    let _isTop;
    try { _isTop = window.top === window; } catch (_) { _isTop = true; }
    if (_isTop && !location.href.includes('/plugin/biz/caseInfo/prepareCreate')) return;

    let count = 0;
    let timer = 0;
    const notify = () => {
      count += 1;
      const phone = readCreateFormPhoneFromDocument(document, window.location.href);
      if (phone) {
        try {
          window.parent.postMessage({ type: PHONE_CAPTURE_MESSAGE, phone }, '*');
          window.top.postMessage({ type: PHONE_CAPTURE_MESSAGE, phone }, '*');
        } catch (_) {}
      }
      if (phone || count > 40) {
        clearInterval(timer);
        try { observer.disconnect(); } catch (_) {}
      }
    };

    const observer = new MutationObserver(notify);
    try {
      observer.observe(document.documentElement, { childList: true, subtree: true, attributes: true, attributeFilter: ['value', 'src'] });
    } catch (_) {}
    timer = window.setInterval(notify, 250);
    notify();
  }

  window.addEventListener('message', (event) => {
    const data = event && event.data;
    if (!data || data.type !== PHONE_CAPTURE_MESSAGE) return;
    maybeResolveActivePhoneCapture(data.phone);
  });

  function getEventKey(card) {
    if (!card) return 'unknown';
    const caseIdCarrier = card.querySelector('[caseid]') || card.closest('[caseid]');
    const caseId = caseIdCarrier && caseIdCarrier.getAttribute('caseid');
    if (caseId) return `caseid:${caseId}`;
    const text = normalizeText(removeOwnText(card.textContent)).slice(0, 220);
    return text || `card:${Date.now()}`;
  }

  function getPhoneRowLabel(row) {
    const labelEl = row && row.querySelector('.lg-form-label, .jd-form-item__label, label, [class*="form-label"]');
    const labelText = cleanLabelText(labelEl && labelEl.textContent);
    return PHONE_LABELS.find((item) => labelText === item || labelText.includes(item)) || '';
  }

  function findPhoneCreateButton(scope, label) {
    if (!scope) return null;
    const shortLabel = String(label || '').replace(/号码$/u, '');
    const buttons = Array.from(scope.querySelectorAll('button.u-icon-chuangshijian12.create-icon, button[aria-label*="以当前事件"][aria-label*="手机号"]'));
    return buttons.find((button) => {
      const aria = button.getAttribute('aria-label') || '';
      return aria.includes('手机号') && (!shortLabel || aria.includes(shortLabel));
    }) || null;
  }

  function getPhoneRows(card) {
    if (!card) return [];
    const rows = [];
    const seen = new Set();
    const labelEls = Array.from(card.querySelectorAll('.lg-form-label, .jd-form-item__label, label, [class*="form-label"]'));

    labelEls.forEach((labelEl) => {
      const labelText = cleanLabelText(labelEl.textContent);
      const label = PHONE_LABELS.find((item) => labelText === item || labelText.includes(item));
      if (!label || seen.has(label)) return;

      const row = labelEl.closest('.j-detail-label, .lg-form-item, .jd-form-item, [class*="form-item"]') || labelEl.parentElement;
      if (!row) return;
      const content = row.querySelector('.lg-form-content, .jd-form-item__content, [class*="form-content"]') || labelEl.nextElementSibling || row;
      const userName = content.querySelector('.user-name') || null;
      const userNameSpan = userName && (userName.querySelector('span') || userName);
      const input = content.querySelector('input.selected_content_input, input');
      const masked = findMaskedPhone((userNameSpan && userNameSpan.textContent) || (input && input.value) || content.textContent);
      const createButton = findPhoneCreateButton(row, label) || findPhoneCreateButton(content, label);
      const fieldKey = `${getEventKey(card)}::${label}::${masked || normalizeText(content.textContent).slice(0, 40)}`;
      rows.push({ label, row, content, userName, userNameSpan, input, masked, createButton, card, fieldKey });
      seen.add(label);
    });

    return rows;
  }

  function ensureRealPhoneMarker(item) {
    const anchor = item.userName || item.input || item.content;
    if (!anchor || !anchor.parentNode) return null;
    let marker = item.content.querySelector(`.${REAL_PHONE_CLASS}[data-uad-label="${item.label}"]`);
    if (!marker) {
      marker = document.createElement('span');
      marker.className = REAL_PHONE_CLASS;
      marker.setAttribute('data-uad-label', item.label);
      anchor.parentNode.insertBefore(marker, anchor.nextSibling);
    }
    return marker;
  }

  function updateRealPhoneMarker(marker, state, value, title) {
    if (!marker) return;
    marker.classList.toggle('is-loading', state === 'loading');
    marker.classList.toggle('is-error', state === 'error');
    if (state === 'loading') {
      marker.textContent = '查询中';
      marker.title = title || 'uad工具：正在读取创建事件面板中的真实手机号';
    } else if (state === 'error') {
      marker.textContent = value || '未识别';
      marker.title = title || 'uad工具：未能从当前事件读取真实手机号';
    } else {
      marker.textContent = value;
      marker.title = title || 'uad工具：真实手机号';
    }
  }

  function setPhoneQueryButtonState(button, state) {
    if (!button) return;
    button.classList.toggle('is-loading', state === 'loading');
    button.classList.toggle('is-done', state === 'done');
    button.classList.toggle('is-error', state === 'error');
    if (state === 'loading') {
      button.textContent = '查询中';
      button.title = 'uad工具：正在读取当前事件手机号';
    } else if (state === 'done') {
      button.textContent = '已查询';
      button.title = 'uad工具：真实手机号已显示在对应号码后面';
    } else if (state === 'error') {
      button.textContent = '查询失败';
      button.title = 'uad工具：未读取到当前事件的真实手机号';
    } else {
      button.textContent = '查询手机号码';
      button.title = '点击后读取绑定号码、来电号码、收货号码、联系号码的真实手机号';
    }
  }

  function upsertPhoneQueryButton(parent, processButton) {
    let queryButton = parent.querySelector(`.${QUERY_PHONE_BUTTON_CLASS}`);
    if (!queryButton) {
      queryButton = document.createElement('button');
      queryButton.type = 'button';
      queryButton.className = QUERY_PHONE_BUTTON_CLASS;
      queryButton.setAttribute('data-uad-role', 'query-phone');
      setPhoneQueryButtonState(queryButton, 'idle');
      const marker = parent.querySelector(`.${MARKER_CLASS}`);
      parent.insertBefore(queryButton, marker || processButton);
    }
    queryButton.__uadProcessButton = processButton;
    return queryButton;
  }

  function closeCreateDialogAfterCapture() {
    window.setTimeout(() => {
      const related = document.querySelector('#caseClueValueShow, input[name="clueValShow"], iframe[src*="/plugin/biz/caseInfo/prepareCreate"]');
      const container = related && (related.closest('.jd-dialog-modal, .jd-overlay, .jd-dialog, .el-dialog__wrapper, .jd-drawer') || related.parentElement);
      const closeButton = container && (container.querySelector('button[aria-label*="关闭"], .jd-dialog__headerbtn, .jd-dialog__close, .el-dialog__headerbtn, .jd-drawer__close-btn') || null);
      if (closeButton) clickLikeUser(closeButton);
    }, 80);
  }

  function capturePhoneFromOriginalButton(item) {
    if (!item || !item.createButton) return Promise.resolve('');

    return new Promise((resolve) => {
      let done = false;
      let timer = 0;
      let timeout = 0;
      let observer = null;

      const finish = (phone) => {
        const full = cleanFullPhone(phone);
        if (full && item.masked && !matchesMaskedPhone(full, item.masked)) return;
        if (done) return;
        done = true;
        if (activePhoneCapture && activePhoneCapture.resolve === finish) activePhoneCapture = null;
        document.documentElement.classList.remove(PHONE_SILENT_CLASS);
        if (timer) clearInterval(timer);
        if (timeout) clearTimeout(timeout);
        try { observer && observer.disconnect(); } catch (_) {}
        if (full) closeCreateDialogAfterCapture();
        resolve(full || '');
      };

      activePhoneCapture = { masked: item.masked, resolve: finish };
      document.documentElement.classList.add(PHONE_SILENT_CLASS);

      const tryRead = () => {
        const phone = readCreateFormPhoneFromAnyFrame();
        if (phone) finish(phone);
      };

      try {
        observer = new MutationObserver(tryRead);
        observer.observe(document.documentElement, { childList: true, subtree: true, attributes: true, attributeFilter: ['src', 'value'] });
      } catch (_) {}

      try {
        clickLikeUser(item.createButton);
      } catch (_) {}

      timer = window.setInterval(tryRead, 200);
      timeout = window.setTimeout(() => finish(''), 6500);
      window.setTimeout(tryRead, 80);
      window.setTimeout(tryRead, 300);
    });
  }

  function visibleFullPhoneFromRow(item) {
    return cleanFullPhone(
      (item.userNameSpan && item.userNameSpan.textContent) ||
      (item.input && item.input.value) ||
      item.content.textContent ||
      ''
    );
  }

  function fullPhoneFromSmallDom(item) {
    const text = [item.row && item.row.textContent, item.content && item.content.textContent].map(removeOwnText).join(' ');
    const phones = findFullPhones(text);
    if (!item.masked) return phones[0] || '';
    return phones.find((phone) => matchesMaskedPhone(phone, item.masked)) || '';
  }

  async function resolveRealPhone(item) {
    const cached = realPhoneCache.get(item.fieldKey);
    if (cached) return cached;
    if (realPhonePending.has(item.fieldKey)) return realPhonePending.get(item.fieldKey);

    const task = (async () => {
      const visible = visibleFullPhoneFromRow(item);
      if (visible) return visible;

      const local = fullPhoneFromSmallDom(item);
      if (local) return local;

      const fromButton = await capturePhoneFromOriginalButton(item);
      if (fromButton) return fromButton;

      return '';
    })();

    realPhonePending.set(item.fieldKey, task);
    try {
      const phone = await task;
      if (phone) realPhoneCache.set(item.fieldKey, phone);
      return phone;
    } finally {
      realPhonePending.delete(item.fieldKey);
    }
  }

  async function queryPhonesForEvent(processButton, queryButton) {
    if (!processButton) return;
    const card = getEventCardFromButton(processButton);
    const rows = getPhoneRows(card);
    if (!rows.length) {
      setPhoneQueryButtonState(queryButton, 'error');
      return;
    }

    setPhoneQueryButtonState(queryButton, 'loading');
    let okCount = 0;
    const byMask = new Map();

    for (const item of rows) {
      const marker = ensureRealPhoneMarker(item);
      updateRealPhoneMarker(marker, 'loading', '查询中');
      try {
        let phone = await resolveRealPhone(item);
        if (!phone && item.masked && byMask.has(item.masked)) phone = byMask.get(item.masked);
        if (phone) {
          okCount += 1;
          if (item.masked) byMask.set(item.masked, phone);
          updateRealPhoneMarker(marker, 'done', phone, `uad工具：已读取${item.label}真实手机号`);
        } else {
          updateRealPhoneMarker(marker, 'error', '未识别', `uad工具：${item.label}未找到可用的“以此创建”手机号数据`);
        }
      } catch (error) {
        updateRealPhoneMarker(marker, 'error', '读取失败', `uad工具：读取${item.label}失败：${error && error.message ? error.message : error}`);
      }
    }

    // 二次补全：同一事件中相同脱敏号共用已读取到的完整号。
    rows.forEach((item) => {
      if (!item.masked || !byMask.has(item.masked)) return;
      const marker = ensureRealPhoneMarker(item);
      if (marker && /未识别|读取失败|查询中/.test(marker.textContent || '')) {
        updateRealPhoneMarker(marker, 'done', byMask.get(item.masked), `uad工具：同一事件相同脱敏号补全${item.label}`);
        okCount += 1;
      }
    });

    setPhoneQueryButtonState(queryButton, okCount > 0 ? 'done' : 'error');
  }

  document.addEventListener('click', (event) => {
    const queryButton = event.target && event.target.closest ? event.target.closest(`.${QUERY_PHONE_BUTTON_CLASS}`) : null;
    if (!queryButton) return;
    event.preventDefault();
    event.stopPropagation();
    if (queryButton.classList.contains('is-loading')) return;
    const processButton = queryButton.__uadProcessButton || Array.from((queryButton.parentElement || document).querySelectorAll('button')).find(isProcessEventButton);
    queryPhonesForEvent(processButton, queryButton);
  }, true);

  // 命中标记点击刷新
  document.addEventListener('click', (event) => {
    const marker = event.target && event.target.closest ? event.target.closest(`.${HIT_MARKER_CLASS}`) : null;
    if (!marker) return;
    event.preventDefault();
    event.stopPropagation();
    if (marker.classList.contains('is-loading')) return;
    const caseId = marker.getAttribute('data-caseid');
    if (!caseId) return;
    // 删除缓存，强制重新查询
    hitStatusCache.delete(caseId);
    saveHitStatusToStorage();
    // 移除SMS时效标记
    removeSmsValidMarker(marker.parentElement && Array.from(marker.parentElement.querySelectorAll('button')).find(isProcessEventButton));
    marker.textContent = '刷新中...';
    marker.classList.add('is-loading');
    marker.classList.remove('is-hit', 'is-no-hit');
    // 找到对应的按钮和卡片
    const parent = marker.parentElement;
    const processButton = parent && Array.from(parent.querySelectorAll('button')).find(isProcessEventButton);
    const card = processButton ? getEventCardFromButton(processButton) : null;
    if (card) {
      queryCaseHitStatus(caseId, card, true);
    } else {
      // 找不到卡片时仅删除缓存，等下次扫描自动重查
      scheduleScan();
    }
  }, true);

  startCreateFrameNotifier();

  function upsertMarker(button, result, createdR, serviceStatus, eventSource, eventSummary) {
    const parent = button.parentElement;
    if (!parent) return;

    let marker = parent.querySelector(`.${MARKER_CLASS}`);
    if (!marker) {
      marker = document.createElement('span');
      marker.className = MARKER_CLASS;
      parent.insertBefore(marker, button);
    }

    upsertPhoneQueryButton(parent, button);

    marker.textContent = result;
    marker.title = markerTitle(createdR, serviceStatus, result, eventSource, eventSummary);
    marker.classList.toggle('is-check', result === '考核');
    marker.classList.toggle('is-no-check', result === '不考核');
  }

  function removeMarker(button) {
    const parent = button.parentElement;
    const marker = parent && parent.querySelector(`.${MARKER_CLASS}`);
    const queryButton = parent && parent.querySelector(`.${QUERY_PHONE_BUTTON_CLASS}`);
    if (marker) marker.remove();
    if (queryButton) queryButton.remove();
  }

  /* -------------------- 命中/未命中标记（基础信息标题旁） -------------------- */

  function upsertHitMarker(button, hitStatus, caseId) {
    const parent = button && button.parentElement;
    if (!parent) {
      if (HIT_DEBUG) console.log('[UAD-HIT] upsertHitMarker: button 无 parent，跳过');
      return;
    }

    // 精确查找：优先通过 data-caseid 查找，其次通过按钮前面的兄弟元素查找
    let marker = null;
    if (caseId) {
      marker = parent.querySelector(`.${HIT_MARKER_CLASS}[data-caseid="${caseId}"]`);
    }
    if (!marker) {
      // 从按钮向前查找相邻的命中标记
      let prev = button.previousElementSibling;
      while (prev) {
        if (prev.classList.contains(HIT_MARKER_CLASS)) { marker = prev; break; }
        prev = prev.previousElementSibling;
      }
    }
    if (!marker) {
      marker = document.createElement('span');
      marker.className = HIT_MARKER_CLASS;
      // 插入到按钮之前（考核标记和SMS标记之后）
      parent.insertBefore(marker, button);
      // 增加与按钮的间距
      marker.style.marginRight = '12px';
      if (HIT_DEBUG) console.log('[UAD-HIT] upsertHitMarker: 创建新标记 caseId:', caseId, 'hitStatus:', hitStatus);
    }

    // 存储 caseId 供点击刷新使用
    if (caseId) marker.setAttribute('data-caseid', caseId);

    const isHit = hitStatus === '已命中';
    const isLoading = hitStatus === 'pending';
    const isError = hitStatus === '查询失败';
    marker.textContent = isLoading ? '查询中...' : hitStatus;
    marker.title = isLoading ? '正在查询命中状态...' : isError ? '查询失败，点击重试' : `点击可刷新命中状态（当前：${hitStatus}）`;
    marker.classList.toggle('is-hit', isHit);
    marker.classList.toggle('is-no-hit', !isHit && !isLoading && !isError);
    marker.classList.toggle('is-loading', isLoading);
    marker.classList.toggle('is-error', isError);
  }

  function removeHitMarker(button) {
    const parent = button && button.parentElement;
    if (!parent) return;
    // 从按钮向前查找相邻的命中标记
    let prev = button.previousElementSibling;
    while (prev) {
      const next = prev.previousElementSibling;
      if (prev.classList.contains(HIT_MARKER_CLASS)) { prev.remove(); break; }
      prev = next;
    }
    removeSmsValidMarker(button);
  }

  /* ---- SMS时效标记（倒计时/已过期/不显示） ---- */

  // 倒计时更新定时器
  let countdownTimer = null;

  function formatCountdown(ms) {
    if (ms <= 0) return '已过期';
    const days = Math.floor(ms / (24 * 3600 * 1000));
    const hours = Math.floor((ms % (24 * 3600 * 1000)) / (3600 * 1000));
    const minutes = Math.floor((ms % (3600 * 1000)) / (60 * 1000));
    const seconds = Math.floor((ms % (60 * 1000)) / 1000);
    if (days > 0) {
      return `${days}天${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
    }
    return `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
  }

  function updateCountdownDisplay() {
    const markers = document.querySelectorAll(`.${SMS_VALID_MARKER_CLASS}`);
    let hasActive = false;
    markers.forEach((marker) => {
      const caseId = marker.getAttribute('data-caseid');
      if (!caseId) return;
      const entry = hitStatusCache.get(caseId);
      if (!entry || !entry.sendTime) return;
      const sendTime = new Date(entry.sendTime).getTime();
      if (isNaN(sendTime)) return;
      const targetTime = sendTime + HIT_VALID_WINDOW_MS;
      const remaining = targetTime - Date.now();
      if (remaining > 0) {
        // 有效期内：更新倒计时文本
        marker.textContent = formatCountdown(remaining);
        marker.title = `短信发送时间：${entry.sendTime}，倒计时截止：${new Date(targetTime).toLocaleString()}`;
        marker.classList.add('is-valid');
        marker.classList.remove('is-expired');
        hasActive = true;
      } else {
        // 已过期：更新标记文本和样式
        marker.textContent = '已过期';
        marker.title = `短信发送时间：${entry.sendTime}，已于 ${new Date(targetTime).toLocaleString()} 过期`;
        marker.classList.remove('is-valid');
        marker.classList.add('is-expired');
        // 同时更新缓存中的状态
        if (entry.smsStatus === '有效') {
          entry.smsStatus = '已过期';
          entry.hitStatus = '未命中';
          saveHitStatusToStorage();
          // 同步更新命中标记
          const parent = marker.parentElement;
          const hitMarker = parent && parent.querySelector(`.${HIT_MARKER_CLASS}[data-caseid="${caseId}"]`);
          if (hitMarker) {
            hitMarker.textContent = '未命中';
            hitMarker.classList.remove('is-hit');
            hitMarker.classList.add('is-no-hit');
          }
        }
        hasActive = true; // 已过期也需要定时器更新（刚过期时需刷新）
      }
    });
    // 清理已不存在的SMS时效标记
    document.querySelectorAll(`.${SMS_VALID_MARKER_CLASS}`).forEach((el) => {
      const caseId = el.getAttribute('data-caseid');
      if (!caseId) return;
      const entry = hitStatusCache.get(caseId);
      if (!entry || entry.smsStatus === '无' || entry.smsStatus === 'pending') {
        el.remove();
      }
    });
    // 如果没有活动的倒计时，清除定时器
    if (!hasActive && countdownTimer) {
      clearInterval(countdownTimer);
      countdownTimer = null;
    }
  }

  function startCountdownTimer() {
    if (countdownTimer) return;
    countdownTimer = setInterval(updateCountdownDisplay, 1000);
  }

  function upsertSmsValidMarker(button, smsStatus, caseId) {
    const parent = button && button.parentElement;
    if (!parent) return;

    // smsStatus 为 '无' 或 'pending' 时不显示
    if (smsStatus === '无' || smsStatus === 'pending') {
      removeSmsValidMarker(button);
      return;
    }

    // 精确查找：优先通过 data-caseid 查找，其次通过按钮前面的兄弟元素查找
    let marker = null;
    if (caseId) {
      marker = parent.querySelector(`.${SMS_VALID_MARKER_CLASS}[data-caseid="${caseId}"]`);
    }
    if (!marker) {
      // 从按钮向前查找相邻的SMS时效标记
      let prev = button.previousElementSibling;
      while (prev) {
        if (prev.classList.contains(SMS_VALID_MARKER_CLASS)) { marker = prev; break; }
        prev = prev.previousElementSibling;
      }
    }
    if (!marker) {
      marker = document.createElement('span');
      marker.className = SMS_VALID_MARKER_CLASS;
      // 插入到按钮之前（命中标记之后）
      parent.insertBefore(marker, button);
    }

    // 存储 caseId 供倒计时更新使用
    if (caseId) marker.setAttribute('data-caseid', caseId);

    const isValid = smsStatus === '有效';
    const isExpired = smsStatus === '已过期';
    marker.classList.toggle('is-valid', isValid);
    marker.classList.toggle('is-expired', isExpired);

    if (isValid) {
      // 有效期内：显示倒计时文本（由 updateCountdownDisplay 更新）
      const entry = hitStatusCache.get(caseId);
      if (entry && entry.sendTime) {
        const sendMs = new Date(entry.sendTime).getTime();
        const remaining = (sendMs + HIT_VALID_WINDOW_MS) - Date.now();
        marker.textContent = formatCountdown(remaining);
        marker.title = `短信发送时间：${entry.sendTime}，倒计时截止：${new Date(sendMs + HIT_VALID_WINDOW_MS).toLocaleString()}`;
      } else {
        marker.textContent = '有效';
      }
      startCountdownTimer();
    } else if (isExpired) {
      marker.textContent = '已过期';
      const entry = hitStatusCache.get(caseId);
      if (entry && entry.sendTime) {
        const sendMs = new Date(entry.sendTime).getTime();
        const deadline = sendMs + HIT_VALID_WINDOW_MS;
        marker.title = `短信发送时间：${entry.sendTime}，已于 ${new Date(deadline).toLocaleString()} 过期`;
      }
    }
  }

  function removeSmsValidMarker(button) {
    const parent = button && button.parentElement;
    if (!parent) return;
    // 从按钮向前查找相邻的SMS时效标记
    let prev = button.previousElementSibling;
    while (prev) {
      const next = prev.previousElementSibling;
      if (prev.classList.contains(SMS_VALID_MARKER_CLASS)) { prev.remove(); break; }
      prev = next;
    }
  }

  function scanEventMarkersOnce() {
    injectMarkerStyle();

    // 检测事件切换：当前页面事件号变化时记录日志
    const activeCaseId = getCurrentCaseId();
    if (activeCaseId && activeCaseId !== lastActiveCaseId) {
      if (HIT_DEBUG) console.log('[UAD-HIT] 事件切换检测: lastActiveCaseId:', lastActiveCaseId, '→ activeCaseId:', activeCaseId);
      lastActiveCaseId = activeCaseId;
    }

    const buttons = Array.from(document.querySelectorAll('button')).filter(isProcessEventButton);
    if (HIT_DEBUG && buttons.length > 0) {
      console.log('[UAD-HIT] scanEventMarkersOnce: 找到', buttons.length, '个"处理此事件"按钮');
    }

    // 收集当前所有按钮对应的 caseId，用于清理残留标记
    const activeCaseIds = new Set();

    buttons.forEach((button) => {
      const card = getEventCardFromButton(button);
      const createdR = getCreatedRStatus(card);
      const serviceStatus = getServiceStatus(card);
      const eventSource = getEventSource(card);
      const eventSummary = getEventSummary(card);
      const result = judgeResult(createdR, serviceStatus, eventSource, eventSummary);

      if (!result) {
        removeMarker(button);
        removeHitMarker(button);
        return;
      }

      upsertMarker(button, result, createdR, serviceStatus, eventSource, eventSummary);

      // 查询命中状态（SMS）—— 每个按钮只用自己的 caseId
      const caseId = getCaseIdFromCard(card);
      if (caseId) activeCaseIds.add(caseId);

      if (HIT_DEBUG) {
        console.log('[UAD-HIT] scanEventMarkersOnce: caseId:', caseId, 'card:', card ? card.tagName : 'null');
      }
      if (caseId) {
        // 无缓存时触发查询（queryCaseHitStatus 内部会设置 pending 状态）
        if (!hitStatusCache.has(caseId)) {
          if (HIT_DEBUG) console.log('[UAD-HIT] 触发查询 caseId:', caseId);
          queryCaseHitStatus(caseId, card);
        }
        // queryCaseHitStatus 已设置 pending，所以 entry 一定存在
        const entry = hitStatusCache.get(caseId);
        if (entry) {
          if (HIT_DEBUG) console.log('[UAD-HIT] 更新标记 caseId:', caseId, 'hitStatus:', entry.hitStatus, 'smsStatus:', entry.smsStatus);
          // 命中标记：始终显示（已命中/未命中/查询中/查询失败）
          upsertHitMarker(button, entry.hitStatus, caseId);
          // SMS时效标记：有效显示倒计时，已过期显示已过期，无则不显示
          upsertSmsValidMarker(button, entry.smsStatus || '无', caseId);
        }
      } else {
        if (HIT_DEBUG) console.log('[UAD-HIT] caseId 为空，移除命中标记');
        removeHitMarker(button);
      }
    });

    // 清理残留的命中/SMS时效标记（data-caseid 不在当前活跃 caseId 集合中的）
    if (activeCaseIds.size > 0) {
      document.querySelectorAll(`.${HIT_MARKER_CLASS}[data-caseid]`).forEach((marker) => {
        const markerCaseId = marker.getAttribute('data-caseid');
        if (markerCaseId && !activeCaseIds.has(markerCaseId)) {
          if (HIT_DEBUG) console.log('[UAD-HIT] 清理残留命中标记 caseId:', markerCaseId);
          marker.remove();
        }
      });
      document.querySelectorAll(`.${SMS_VALID_MARKER_CLASS}[data-caseid]`).forEach((marker) => {
        const markerCaseId = marker.getAttribute('data-caseid');
        if (markerCaseId && !activeCaseIds.has(markerCaseId)) {
          if (HIT_DEBUG) console.log('[UAD-HIT] 清理残留SMS标记 caseId:', markerCaseId);
          marker.remove();
        }
      });
    }
  }

  /* -------------------- kfuad 强制转移按钮 -------------------- */

  const FORCE_TRANSFER_BTN_CLASS = 'uad-force-transfer-btn';
  const FORCE_TRANSFER_PANEL_ID = 'uad-force-transfer-panel';
  const FORCE_TRANSFER_OVERLAY_ID = 'uad-force-transfer-overlay';
  const FORCE_TRANSFER_STYLE_ID = 'uad-force-transfer-style';
  const FORCE_TRANSFER_REASONS = ['休假', '超出业务范围', '升级错误'];

  function isKfuadPage() {
    return location.hostname === 'kfuad.jd.com';
  }

  function injectForceTransferStyle() {
    if (document.getElementById('uad-ft-style')) return;
    const style = document.createElement('style');
    style.id = 'uad-ft-style';
    style.textContent = `
      /* ===== 强制转移面板 jd-dialog 风格 ===== */
      #${FORCE_TRANSFER_PANEL_ID} {
        display: none;
        position: fixed;
        top: 80px;
        left: 50%;
        transform: translateX(-50%);
        z-index: 99999;
        background: #fff;
        border-radius: 2px;
        box-shadow: 0 8px 32px rgba(0,0,0,0.18);
        width: 420px;
        font-size: 14px;
        color: #333;
        overflow: hidden;
        user-select: none;
      }
      #${FORCE_TRANSFER_PANEL_ID}.visible { display: block; }
      /* header */
      .uad-ft-dialog-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 16px 20px 12px;
        border-bottom: 1px solid #e4e7ed;
        cursor: move;
      }
      .uad-ft-dialog-title {
        font-size: 15px;
        font-weight: 600;
        color: #303133;
        line-height: 1;
      }
      .uad-ft-dialog-close {
        display: flex; align-items: center; justify-content: center;
        width: 24px; height: 24px;
        background: none; border: none;
        font-size: 18px; color: #909399;
        cursor: pointer; border-radius: 2px;
        line-height: 1; padding: 0;
      }
      .uad-ft-dialog-close:hover { color: #303133; background: #f5f7fa; }
      /* body */
      .uad-ft-dialog-body {
        padding: 20px 24px 8px;
      }
      /* jd-form layout */
      .uad-ft-form { display: block; }
      .uad-ft-form-item {
        display: flex;
        align-items: center;
        margin-bottom: 18px;
      }
      .uad-ft-form-label {
        width: 72px;
        flex-shrink: 0;
        text-align: right;
        padding-right: 8px;
        line-height: 28px;
        color: #606266;
        font-size: 14px;
        box-sizing: border-box;
        white-space: nowrap;
      }
      .uad-ft-form-label.required::before {
        content: '*';
        color: #f56c6c;
        margin-right: 4px;
      }
      .uad-ft-form-content { flex: 1; min-width: 0; }
      /* input */
      .uad-ft-input-wrap {
        display: inline-flex; align-items: center;
        width: 100%;
        border: 1px solid #dcdfe6;
        border-radius: 2px;
        background: #fff;
        box-sizing: border-box;
        transition: border-color .2s;
      }
      .uad-ft-input-wrap:focus-within { border-color: #3875f6; }
      .uad-ft-input-inner {
        flex: 1; height: 28px;
        border: none; outline: none;
        padding: 0 8px;
        font-size: 13px; color: #333;
        background: transparent;
        box-sizing: border-box;
        min-width: 0;
      }
      .uad-ft-input-inner::placeholder { color: #c0c4cc; }
      /* select */
      .uad-ft-select-wrap {
        display: flex; align-items: center;
        width: 100%;
        border: 1px solid #dcdfe6;
        border-radius: 2px;
        background: #fff;
        box-sizing: border-box;
        transition: border-color .2s;
        position: relative;
      }
      .uad-ft-select-wrap:focus-within { border-color: #3875f6; }
      .uad-ft-select-inner {
        flex: 1; height: 28px;
        border: none; outline: none;
        padding: 0 8px;
        font-size: 13px; color: #333;
        background: transparent;
        appearance: none; -webkit-appearance: none;
        cursor: pointer;
        box-sizing: border-box;
      }
      .uad-ft-select-arrow {
        position: absolute; right: 8px;
        width: 12px; height: 12px;
        pointer-events: none;
        color: #c0c4cc;
      }
      /* textarea */
      .uad-ft-textarea-wrap {
        display: block;
        width: 100%;
        border: 1px solid #dcdfe6;
        border-radius: 2px;
        background: #fff;
        box-sizing: border-box;
        position: relative;
        transition: border-color .2s;
      }
      .uad-ft-textarea-wrap:focus-within { border-color: #3875f6; }
      .uad-ft-textarea-inner {
        display: block; width: 100%;
        min-height: 90px; height: 90px;
        border: none; outline: none;
        padding: 6px 8px;
        font-size: 13px; color: #333;
        background: transparent;
        resize: vertical; font-family: inherit;
        box-sizing: border-box;
        line-height: 1.5;
      }
      .uad-ft-textarea-inner::placeholder { color: #c0c4cc; }
      .uad-ft-char-count {
        display: block;
        text-align: right;
        font-size: 12px;
        color: #909399;
        padding: 2px 6px 4px;
      }
      /* msg */
      #uad-ft-msg {
        padding: 0 24px 10px;
        font-size: 13px;
        min-height: 18px;
      }
      #uad-ft-msg.success { color: #67c23a; }
      #uad-ft-msg.error { color: #f56c6c; }
      /* footer */
      .uad-ft-dialog-footer {
        display: flex;
        justify-content: flex-end;
        align-items: center;
        gap: 10px;
        padding: 10px 20px 16px;
        border-top: 1px solid #e4e7ed;
      }
      .uad-ft-btn {
        display: inline-flex; align-items: center; justify-content: center;
        height: 28px; padding: 0 15px;
        border-radius: 2px;
        font-size: 13px; cursor: pointer;
        border: 1px solid #dcdfe6;
        background: #fff; color: #606266;
        transition: all .2s;
        min-width: 64px;
        white-space: nowrap;
        box-sizing: border-box;
      }
      .uad-ft-btn:hover { background: #f5f7fa; color: #303133; border-color: #c6cad1; }
      .uad-ft-btn.primary {
        background: #3875f6; border-color: #3875f6; color: #fff;
      }
      .uad-ft-btn.primary:hover { background: #2563eb; border-color: #2563eb; }
      .uad-ft-btn:disabled { opacity: .6; cursor: not-allowed; }
    `;
    document.documentElement.appendChild(style);
  }

  function getCurrentCaseId() {
    // 方法1：从整页 innerText 提取"事件号"后的数字（最可靠）
    const bodyTxt = (document.body && document.body.innerText) || '';
    const m1 = bodyTxt.match(/事件号[\s\S]{0,4}?([0-9]{8,})/);
    if (m1) return m1[1];
    // 方法2：TreeWalker 遍历文本节点
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
    let node;
    while ((node = walker.nextNode())) {
      if (/事件号/.test(node.nodeValue)) {
        const nm = node.nodeValue.match(/([0-9]{8,})/);
        if (nm) return nm[1];
        let sib = node.nextSibling;
        for (let i = 0; i < 5 && sib; i++, sib = sib.nextSibling) {
          const sm = (sib.textContent || '').trim().match(/^([0-9]{8,})/);
          if (sm) return sm[1];
        }
      }
    }
    // 方法3：data-caseid 属性
    for (const el of document.querySelectorAll('[data-caseid]')) {
      const dm = String(el.getAttribute('data-caseid')).match(/[0-9]{8,}/);
      if (dm) return dm[0];
    }
    // 方法4：URL 路径
    const urlM = location.href.match(/\/([0-9]{8,})(?:[\/?#]|$)/);
    if (urlM) return urlM[1];
    return '';
  }

  function buildForceTransferPanel() {
    if (document.getElementById(FORCE_TRANSFER_PANEL_ID)) return;
    injectForceTransferStyle();

    // 浮动面板（无遮罩）
    const panel = document.createElement('div');
    panel.id = FORCE_TRANSFER_PANEL_ID;

    // ---- 头部（可拖拽）----
    const header = document.createElement('div');
    header.className = 'uad-ft-dialog-header';

    const titleEl = document.createElement('span');
    titleEl.className = 'uad-ft-dialog-title';
    titleEl.textContent = '转移事件';

    const closeBtn = document.createElement('button');
    closeBtn.className = 'uad-ft-dialog-close';
    closeBtn.innerHTML = '&#215;';
    closeBtn.title = '关闭';

    header.appendChild(titleEl);
    header.appendChild(closeBtn);

    // ---- 表单区 ----
    const body = document.createElement('div');
    body.className = 'uad-ft-dialog-body';

    const form = document.createElement('div');
    form.className = 'uad-ft-form';

    // 事件号（只读）
    const rowCaseId = document.createElement('div');
    rowCaseId.className = 'uad-ft-form-item';
    const labelCaseId = document.createElement('label');
    labelCaseId.className = 'uad-ft-form-label required';
    labelCaseId.textContent = '事件号：';
    const contentCaseId = document.createElement('div');
    contentCaseId.className = 'uad-ft-form-content';
    const wrapCaseId = document.createElement('div');
    wrapCaseId.className = 'uad-ft-input-wrap readonly';
    const inputCaseId = document.createElement('input');
    inputCaseId.className = 'uad-ft-input-inner';
    inputCaseId.id = 'uad-ft-caseid';
    inputCaseId.placeholder = '';
    // inputCaseId.readOnly = true;  // 允许手动编辑
    wrapCaseId.appendChild(inputCaseId);
    contentCaseId.appendChild(wrapCaseId);
    rowCaseId.appendChild(labelCaseId);
    rowCaseId.appendChild(contentCaseId);

    // 转移到
    const rowTo = document.createElement('div');
    rowTo.className = 'uad-ft-form-item';
    const labelTo = document.createElement('label');
    labelTo.className = 'uad-ft-form-label required';
    labelTo.textContent = '转移到：';
    const contentTo = document.createElement('div');
    contentTo.className = 'uad-ft-form-content';
    const wrapTo = document.createElement('div');
    wrapTo.className = 'uad-ft-input-wrap';
    const inputTo = document.createElement('input');
    inputTo.className = 'uad-ft-input-inner';
    inputTo.id = 'uad-ft-to';
    inputTo.placeholder = '';
    wrapTo.appendChild(inputTo);
    contentTo.appendChild(wrapTo);
    rowTo.appendChild(labelTo);
    rowTo.appendChild(contentTo);

    // 转移原因
    const rowReason = document.createElement('div');
    rowReason.className = 'uad-ft-form-item';
    const labelReason = document.createElement('label');
    labelReason.className = 'uad-ft-form-label required';
    labelReason.textContent = '转移原因：';
    const contentReason = document.createElement('div');
    contentReason.className = 'uad-ft-form-content';
    const wrapReason = document.createElement('div');
    wrapReason.className = 'uad-ft-select-wrap';
    const selectReason = document.createElement('select');
    selectReason.className = 'uad-ft-select-inner';
    selectReason.id = 'uad-ft-reason';
    FORCE_TRANSFER_REASONS.forEach((r) => {
      const opt = document.createElement('option');
      opt.value = r;
      opt.textContent = r;
      selectReason.appendChild(opt);
    });
    const arrowIcon = document.createElement('span');
    arrowIcon.className = 'uad-ft-select-arrow';
    arrowIcon.innerHTML = '<svg viewBox="0 0 1024 1024" width="12" height="12" fill="currentColor"><path d="M512 704L128 288h768z"/></svg>';
    wrapReason.appendChild(selectReason);
    wrapReason.appendChild(arrowIcon);
    contentReason.appendChild(wrapReason);
    rowReason.appendChild(labelReason);
    rowReason.appendChild(contentReason);

    // 转移说明
    const rowNote = document.createElement('div');
    rowNote.className = 'uad-ft-form-item';
    rowNote.style.alignItems = 'flex-start';
    const labelNote = document.createElement('label');
    labelNote.className = 'uad-ft-form-label';
    labelNote.textContent = '转移说明：';
    const contentNote = document.createElement('div');
    contentNote.className = 'uad-ft-form-content';
    const wrapNote = document.createElement('div');
    wrapNote.className = 'uad-ft-textarea-wrap';
    const textareaNote = document.createElement('textarea');
    textareaNote.className = 'uad-ft-textarea-inner';
    textareaNote.id = 'uad-ft-note';
    textareaNote.maxLength = 500;
    textareaNote.placeholder = '选填，最多500字';
    const counter = document.createElement('span');
    counter.className = 'uad-ft-char-count';
    counter.textContent = '0 / 500';
    textareaNote.addEventListener('input', () => {
      counter.textContent = `${textareaNote.value.length} / 500`;
    });
    wrapNote.appendChild(textareaNote);
    wrapNote.appendChild(counter);
    contentNote.appendChild(wrapNote);
    rowNote.appendChild(labelNote);
    rowNote.appendChild(contentNote);

    form.appendChild(rowCaseId);
    form.appendChild(rowTo);
    form.appendChild(rowReason);
    form.appendChild(rowNote);
    body.appendChild(form);

    // 消息区
    const msgEl = document.createElement('div');
    msgEl.id = 'uad-ft-msg';

    // ---- 底部按钮 ----
    const footer = document.createElement('div');
    footer.className = 'uad-ft-dialog-footer';
    const cancelBtn = document.createElement('button');
    cancelBtn.className = 'uad-ft-btn';
    cancelBtn.textContent = '取消';
    const confirmBtn = document.createElement('button');
    confirmBtn.className = 'uad-ft-btn primary';
    confirmBtn.textContent = '确认转移';
    footer.appendChild(cancelBtn);
    footer.appendChild(confirmBtn);

    panel.appendChild(header);
    panel.appendChild(body);
    panel.appendChild(msgEl);
    panel.appendChild(footer);
    document.body.appendChild(panel);

    // ---- 拖拽支持 ----
    let _dragging = false, _dragOffX = 0, _dragOffY = 0;
    header.addEventListener('mousedown', (e) => {
      if (e.target === closeBtn || closeBtn.contains(e.target)) return;
      _dragging = true;
      const rect = panel.getBoundingClientRect();
      _dragOffX = e.clientX - rect.left;
      _dragOffY = e.clientY - rect.top;
      document.addEventListener('mousemove', _onDragMove);
      document.addEventListener('mouseup', _onDragUp);
      e.preventDefault();
    });
    function _onDragMove(e) {
      if (!_dragging) return;
      const x = e.clientX - _dragOffX;
      const y = e.clientY - _dragOffY;
      panel.style.left = x + 'px';
      panel.style.top = y + 'px';
      panel.style.transform = 'none';
    }
    function _onDragUp() {
      _dragging = false;
      document.removeEventListener('mousemove', _onDragMove);
      document.removeEventListener('mouseup', _onDragUp);
    }

    function openPanel(caseId) {
      inputCaseId.value = caseId || getCurrentCaseId();
      inputTo.value = '';
      selectReason.value = FORCE_TRANSFER_REASONS[0];
      textareaNote.value = '';
      counter.textContent = '0 / 500';
      msgEl.textContent = '';
      msgEl.className = '';
      // 重置位置到默认居中
      panel.style.left = '';
      panel.style.top = '';
      panel.style.transform = '';
      panel.classList.add('visible');
      inputTo.focus();
    }

    function closePanel() {
      panel.classList.remove('visible');
    }

    closeBtn.addEventListener('click', closePanel);
    cancelBtn.addEventListener('click', closePanel);

    confirmBtn.addEventListener('click', async () => {
      const caseIds = inputCaseId.value.trim();
      const targetUserPin = inputTo.value.trim();
      const transferValueName = selectReason.value;
      const content = textareaNote.value.trim() || '1';

      if (!caseIds) {
        msgEl.textContent = '请填写事件号';
        msgEl.className = 'error';
        inputCaseId.focus();
        return;
      }
      if (!targetUserPin) {
        msgEl.textContent = '请填写转移到（接受方Pin）';
        msgEl.className = 'error';
        inputTo.focus();
        return;
      }

      confirmBtn.disabled = true;
      confirmBtn.textContent = '提交中...';
      msgEl.textContent = '';
      msgEl.className = '';

      try {
        const normalizedCaseIds = caseIds
          .split(/[,，\s]+/)
          .map((s) => s.trim())
          .filter(Boolean)
          .join(',');
        const payload = { transferValueName, content, transferMode: 1, caseIds: normalizedCaseIds, targetUserPin };
        const resp = await uadFetch('https://case-monitor-new.jd.com/api/batch-transfer', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Accept': 'application/json, text/plain, */*',
           'X-Requested-With': 'XMLHttpRequest'
          },
          body: JSON.stringify(payload)
        });

        const text = resp.text;
        let result = null;
        try { result = JSON.parse(text); } catch (_) {}

        const isSuccess = resp.ok && result && (
          result.status === 200 ||
          result.code === 0 ||
          (result.result && Array.isArray(result.result.success) && result.result.success.length > 0)
        );

        if (isSuccess) {
          const failList = (result.result && result.result.fail) || [];
          const successList = (result.result && result.result.success) || [];
          if (failList.length > 0) {
            msgEl.textContent = `部分成功：成功 ${successList.length} 条，失败 ${failList.length} 条（${failList.join('、')}）`;
            msgEl.className = 'error';
          } else {
            msgEl.textContent = '转移成功！';
            msgEl.className = 'success';
            window.setTimeout(closePanel, 1500);
          }
        } else {
          const errMsg = (result && (result.message || result.msg || result.errMsg)) || text || `HTTP ${resp.status}`;
          msgEl.textContent = `转移失败：${errMsg}`;
          msgEl.className = 'error';
        }
      } catch (err) {
        msgEl.textContent = `请求出错：${err && err.message ? err.message : err}`;
        msgEl.className = 'error';
      } finally {
        confirmBtn.disabled = false;
        confirmBtn.textContent = '确认转移';
      }
    });

    // 暴露 openPanel 供按钮调用
    panel._uadOpenPanel = openPanel;
  }

  function isSaveButton(btn) {
    return btn && btn.tagName === 'BUTTON' && normalizeText(btn.textContent) === '保存';
  }

  function isTransferButton(btn) {
    return btn && btn.tagName === 'BUTTON' && normalizeText(btn.textContent) === '转移';
  }

  function upsertForceTransferButton(saveBtn) {
    const parent = saveBtn.parentElement;
    if (!parent) return;
    if (parent.querySelector(`.${FORCE_TRANSFER_BTN_CLASS}`)) return;

    const transferBtn = Array.from(parent.querySelectorAll('button')).find(isTransferButton);
    if (!transferBtn) return;

    const forceBtn = document.createElement('button');
    forceBtn.type = 'button';
    forceBtn.className = FORCE_TRANSFER_BTN_CLASS;
    forceBtn.textContent = '强制转移';
    forceBtn.title = 'uad工具：强制转移到指定坐席';

    // 样式：与隔壁"转移"按钮保持一致
    const refStyle = window.getComputedStyle(transferBtn);
    forceBtn.style.cssText = `
      display: inline-flex;
      align-items: center;
      justify-content: center;
      min-width: ${transferBtn.offsetWidth || 56}px;
      height: ${transferBtn.offsetHeight || 28}px;
      padding: 0 12px;
      margin: 0 4px;
      border: 1px solid ${refStyle.borderColor || '#dcdfe6'};
      border-radius: ${refStyle.borderRadius || '2px'};
      font-size: ${refStyle.fontSize || '13px'};
      font-weight: ${refStyle.fontWeight || '400'};
      line-height: 1;
      color: ${refStyle.color || '#606266'};
      background: ${refStyle.backgroundColor || '#fff'};
      cursor: pointer;
      outline: none;
      box-sizing: border-box;
      vertical-align: middle;
      transition: border-color .2s, color .2s, background .2s;
    `;
    forceBtn.addEventListener('mouseenter', () => {
      forceBtn.style.borderColor = '#c6e2ff';
      forceBtn.style.color = '#409eff';
      forceBtn.style.background = '#ecf5ff';
    });
    forceBtn.addEventListener('mouseleave', () => {
      forceBtn.style.borderColor = refStyle.borderColor || '#dcdfe6';
      forceBtn.style.color = refStyle.color || '#606266';
      forceBtn.style.background = refStyle.backgroundColor || '#fff';
    });

    // 插入到"保存"和"转移"之间
    parent.insertBefore(forceBtn, transferBtn);

    forceBtn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      buildForceTransferPanel();
      const ftPanel = document.getElementById(FORCE_TRANSFER_PANEL_ID);
      if (ftPanel && ftPanel._uadOpenPanel) {
        ftPanel._uadOpenPanel(getCurrentCaseId());
      }
    });
  }

  function scanForceTransferButtons() {
    if (!isKfuadPage()) return;
    injectForceTransferStyle();
    const saveBtns = Array.from(document.querySelectorAll('button')).filter(isSaveButton);
    saveBtns.forEach(upsertForceTransferButton);
  }

  /* -------------------- 转移事件悬浮面板（case-monitor-new.jd.com/over-case-detail） -------------------- */

  const TRANSFER_PANEL_ID = 'uad-transfer-panel';
  const TRANSFER_BTN_ID = 'uad-transfer-open-btn';
  const TRANSFER_STYLE_ID = 'uad-transfer-style';
  const TRANSFER_REASONS = ['休假', '超出业务范围', '升级错误'];

  function isTransferPage() {
    return location.hostname === 'case-monitor-new.jd.com';
  }

  function injectTransferStyle() {
    if (document.getElementById(TRANSFER_STYLE_ID)) return;
    const style = document.createElement('style');
    style.id = TRANSFER_STYLE_ID;
    style.textContent = `
      #${TRANSFER_BTN_ID} {
        position: fixed;
        right: 20px;
        bottom: 80px;
        z-index: 99998;
        width: 44px;
        height: 44px;
        border-radius: 50%;
        background: #1a73e8;
        color: #fff;
        border: none;
        font-size: 22px;
        line-height: 44px;
        text-align: center;
        cursor: pointer;
        box-shadow: 0 2px 8px rgba(0,0,0,0.18);
        title: '转移事件';
      }
      #${TRANSFER_BTN_ID}:hover { background: #1557b0; }
      #uad-transfer-overlay {
        display: none;
        position: fixed;
        inset: 0;
        z-index: 99999;
        background: rgba(0,0,0,0.35);
        align-items: center;
        justify-content: center;
      }
      #uad-transfer-overlay.visible { display: flex; }
      #${TRANSFER_PANEL_ID} {
        background: #fff;
        border-radius: 6px;
        box-shadow: 0 4px 24px rgba(0,0,0,0.22);
        min-width: 420px;
        max-width: 500px;
        width: 100%;
        font-size: 14px;
        color: #333;
        overflow: hidden;
      }
      #uad-transfer-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        background: #2b5bb8;
        color: #fff;
        padding: 12px 18px;
        font-size: 15px;
        font-weight: 600;
        user-select: none;
      }
      #uad-transfer-close-btn {
        background: none;
        border: none;
        color: #fff;
        font-size: 20px;
        cursor: pointer;
        line-height: 1;
        padding: 0 2px;
      }
   #uad-transfer-body {
        padding: 22px 24px 10px;
      }
      .uad-tf-row {
        display: flex;
        align-items: flex-start;
        margin-bottom: 16px;
      }
      .uad-tf-label {
        width: 76px;
        flex-shrink: 0;
        text-align: right;
        padding-right: 8px;
        line-height: 32px;
        color: #333;
      }
      .uad-tf-label.required::before {
        content: '* ';
        color: #e34d59;
      }
      .uad-tf-input {
        flex: 1;
        height: 32px;
        border: 1px solid #ccc;
        border-radius: 3px;
        padding: 0 8px;
        font-size: 14px;
        outline: none;
        box-sizing: border-box;
      }
      .uad-tf-input:focus { border-color: #1a73e8; }
      .uad-tf-select {
        flex: 1;
        height: 32px;
        border: 1px solid #ccc;
        border-radius: 3px;
        padding: 0 6px;
        font-size: 14px;
        outline: none;
        background: #fff;
        box-sizing: border-box;
        cursor: pointer;
      }
      .uad-tf-select:focus { border-color: #1a73e8; }
      .uad-tf-textarea {
        flex: 1;
        min-height: 100px;
        border: 1px solid #ccc;
        border-radius: 3px;
        padding: 6px 8px;
        font-size: 14px;
        outline: none;
        resize: vertical;
        box-sizing: border-box;
        font-family: inherit;
      }
      .uad-tf-textarea:focus { border-color: #1a73e8; }
      .uad-tf-counter {
        text-align: right;
        font-size: 12px;
        color: #999;
        margin-top: 2px;
        flex-basis: 100%;
      }
      #uad-transfer-footer {
        display: flex;
        justify-content: flex-end;
        gap: 10px;
        padding: 10px 24px 18px;
      }
      .uad-tf-btn {
        min-width: 72px;
        height: 32px;
        border-radius: 3px;
        border: 1px solid #ccc;
        font-size: 14px;
        cursor: pointer;
        padding: 0 18px;
      }
      .uad-tf-btn-confirm {
        background: #1a73e8;
        color: #fff;
        border-color: #1a73e8;
      }
      .uad-tf-btn-confirm:hover { background: #1557b0; border-color: #1557b0; }
      .uad-tf-btn-cancel {
        background: #fff;
        color: #333;
      }
      .uad-tf-btn-cancel:hover { background: #f5f5f5; }
      #uad-transfer-msg {
        padding: 0 24px 12px;
        font-size: 13px;
        min-height: 18px;
      }
      #uad-transfer-msg.success { color: #147a3c; }
      #uad-transfer-msg.error { color: #d93026; }
    `;
    document.documentElement.appendChild(style);
  }

  function getCaseIdsFromPage() {
    // 尝试从页面 URL 参数获取 caseId
    try {
      const params = new URLSearchParams(location.search);
      const caseId = params.get('caseId') || params.get('caseIds') || params.get('id');
      if (caseId) return caseId;
    } catch (_) {}

    // 尝试从页面内容获取
    const possibleEls = Array.from(document.querySelectorAll('[data-caseid], [caseid]'));
    if (possibleEls.length) return possibleEls[0].getAttribute('data-caseid') || possibleEls[0].getAttribute('caseid') || '';

    // 从 URL 路径中提取数字（作为 caseId 备选）
    const pathMatch = location.pathname.match(/(\d{10,})/);
    if (pathMatch) return pathMatch[1];

    return '';
  }

  function buildTransferPanel() {
    if (document.getElementById('uad-transfer-overlay')) return;

    injectTransferStyle();

    // 悬浮触发按钮
    const openBtn = document.createElement('button');
    openBtn.id = TRANSFER_BTN_ID;
    openBtn.title = '转移事件';
    openBtn.textContent = '⇄';
    document.body.appendChild(openBtn);

    // 遮罩层
    const overlay = document.createElement('div');
    overlay.id = 'uad-transfer-overlay';

    // 面板
    const panel = document.createElement('div');
    panel.id = TRANSFER_PANEL_ID;

    // 头部
    const header = document.createElement('div');
    header.id = 'uad-transfer-header';
    header.innerHTML = '<span>转移事件</span>';
    const closeBtn = document.createElement('button');
    closeBtn.id = 'uad-transfer-close-btn';
    closeBtn.textContent = '×';
    header.appendChild(closeBtn);

    // 表单区
    const body = document.createElement('div');
    body.id = 'uad-transfer-body';

    // 事件号
    const rowCaseId = document.createElement('div');
    rowCaseId.className = 'uad-tf-row';
    const labelCaseId = document.createElement('label');
    labelCaseId.className = 'uad-tf-label required';
    labelCaseId.textContent = '事件号：';
    const inputCaseId = document.createElement('input');
    inputCaseId.className = 'uad-tf-input';
    inputCaseId.id = 'uad-tf-caseid';
    inputCaseId.placeholder = '请输入事件号';
    rowCaseId.appendChild(labelCaseId);
    rowCaseId.appendChild(inputCaseId);

    // 转移到
    const rowTo = document.createElement('div');
    rowTo.className = 'uad-tf-row';
    const labelTo = document.createElement('label');
    labelTo.className = 'uad-tf-label required';
    labelTo.textContent = '转移到：';
    const inputTo = document.createElement('input');
    inputTo.className = 'uad-tf-input';
    inputTo.id = 'uad-tf-to';
    inputTo.placeholder = '';
    rowTo.appendChild(labelTo);
    rowTo.appendChild(inputTo);

    // 转移原因
    const rowReason = document.createElement('div');
    rowReason.className = 'uad-tf-row';
    const labelReason = document.createElement('label');
    labelReason.className = 'uad-tf-label required';
    labelReason.textContent = '为何转';
    const selectReason = document.createElement('select');
    selectReason.className = 'uad-tf-select';
    selectReason.id = 'uad-tf-reason';
    TRANSFER_REASONS.forEach((reason) => {
      const opt = document.createElement('option');
      opt.value = reason;
      opt.textContent = reason;
      selectReason.appendChild(opt);
    });
    rowReason.appendChild(labelReason);
    rowReason.appendChild(selectReason);

    // 转移说明
    const rowNote = document.createElement('div');
    rowNote.className = 'uad-tf-row';
    rowNote.style.flexWrap = 'wrap';
    const labelNote = document.createElement('label');
    labelNote.className = 'uad-tf-label';
    labelNote.textContent = '转移说明：';
    const textareaNote = document.createElement('textarea');
    textareaNote.className = 'uad-tf-textarea';
    textareaNote.id = 'uad-tf-note';
    textareaNote.maxLength = 500;
    textareaNote.placeholder = '请输入转移说明（选填，最多500字）';
    const counter = document.createElement('div');
    counter.className = 'uad-tf-counter';
    counter.textContent = '0 / 500';
    textareaNote.addEventListener('input', () => {
      counter.textContent = `${textareaNote.value.length} / 500`;
    });
    rowNote.appendChild(labelNote);
    rowNote.appendChild(textareaNote);
    rowNote.appendChild(counter);

    body.appendChild(rowCaseId);
    body.appendChild(rowTo);
    body.appendChild(rowReason);
    body.appendChild(rowNote);

    // 消息区
    const msgEl = document.createElement('div');
    msgEl.id = 'uad-transfer-msg';

    // 底部按钮
    const footer = document.createElement('div');
    footer.id = 'uad-transfer-footer';
    const cancelBtn = document.createElement('button');
    cancelBtn.className = 'uad-tf-btn uad-tf-btn-cancel';
    cancelBtn.textContent = '取消';
    const confirmBtn = document.createElement('button');
    confirmBtn.className = 'uad-tf-btn uad-tf-btn-confirm';
    confirmBtn.textContent = '确认';
    footer.appendChild(confirmBtn);
    footer.appendChild(cancelBtn);

    panel.appendChild(header);
    panel.appendChild(body);
    panel.appendChild(msgEl);
    panel.appendChild(footer);
    overlay.appendChild(panel);
    document.body.appendChild(overlay);

    // 事件绑定
    function openPanel() {
      inputCaseId.value = '';
      inputTo.value = '';
      selectReason.value = TRANSFER_REASONS[0];
      textareaNote.value = '';
      counter.textContent = '0 / 500';
      msgEl.textContent = '';
      msgEl.className = '';
      overlay.classList.add('visible');
      inputCaseId.focus();
    }

    function closePanel() {
      overlay.classList.remove('visible');
    }

    openBtn.addEventListener('click', openPanel);
    closeBtn.addEventListener('click', closePanel);
    cancelBtn.addEventListener('click', closePanel);
    overlay.addEventListener('click', (e) => {
      if (e.target === overlay) closePanel();
    });

    confirmBtn.addEventListener('click', async () => {
      const caseIds = inputCaseId.value.trim();
      const targetUserPin = inputTo.value.trim();
      const transferValueName = selectReason.value;
      const content = textareaNote.value.trim() || '1';

      if (!caseIds) {
        msgEl.textContent = '请填写事件号';
        msgEl.className = 'error';
        inputCaseId.focus();
        return;
      }
      if (!targetUserPin) {
        msgEl.textContent = '请填写转移到（接受方Pin）';
        msgEl.className = 'error';
        inputTo.focus();
        return;
      }

      confirmBtn.disabled = true;
      confirmBtn.textContent = '提交中...';
      msgEl.textContent = '';
      msgEl.className = '';

      try {
        const normalizedCaseIds = caseIds
          .split(/[,，\s]+/)
          .map((s) => s.trim())
          .filter(Boolean)
          .join(',');
        const payload = {
          transferValueName,
          content,
          transferMode: 1,
          caseIds: normalizedCaseIds,
          targetUserPin
        };

        const resp = await uadFetch('https://case-monitor-new.jd.com/api/batch-transfer', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Accept': 'application/json, text/plain, */*',
            'X-Requested-With': 'XMLHttpRequest'
          },
          body: JSON.stringify(payload)
        });

        const text = resp.text;
        let result = null;
        try { result = JSON.parse(text); } catch (_) {}

        // 接口返回格式：{"status":200,"message":"成功!","result":{"fail":[],"success":[...]}}
        const isSuccess = resp.ok && result && (
          result.status === 200 ||
          result.code === 0 ||
          result.success === true ||
          (result.result && Array.isArray(result.result.success) && result.result.success.length > 0)
        );
        if (isSuccess) {
          const failList = (result.result && result.result.fail) || [];
          const successList = (result.result && result.result.success) || [];
          if (failList.length > 0) {
            msgEl.textContent = `部分成功：成功 ${successList.length} 条，失败 ${failList.length} 条（${failList.join('、')}）`;
            msgEl.className = 'error';
          } else {
            msgEl.textContent = `转移成功！`;
            msgEl.className = 'success';
            window.setTimeout(closePanel, 1500);
          }
        } else {
          const errMsg = (result && (result.message || result.msg || result.errMsg)) || text || `HTTP ${resp.status}`;
          msgEl.textContent = `转移失败：${errMsg}`;
          msgEl.className = 'error';
        }
      } catch (err) {
        msgEl.textContent = `请求出错：${err && err.message ? err.message : err}`;
        msgEl.className = 'error';
      } finally {
        confirmBtn.disabled = false;
        confirmBtn.textContent = '确认';
      }
    });
  }

  function initTransferPanel() {
    if (!isTransferPage()) return;
    if (document.body) {
      buildTransferPanel();
    } else {
      document.addEventListener('DOMContentLoaded', buildTransferPanel, { once: true });
    }
  }

  /* -------------------- 统一调度 -------------------- */

  function scanOnce() {
    scanSmartFollowOnce();
    scanEventMarkersOnce();
    scanForceTransferButtons();
  }

  function scheduleScan() {
    if (scanTimer) return;
    scanTimer = window.setTimeout(() => {
      scanTimer = 0;
      scanOnce();
    }, 120);
  }

  const observer = new MutationObserver(scheduleScan);
  observer.observe(document.documentElement, {
    childList: true,
    subtree: true,
    attributes: true,
    attributeFilter: ['class', 'style', 'aria-hidden', 'checked', 'value']
  });

  window.setInterval(scheduleScan, SCAN_INTERVAL_MS);
  scheduleScan();

  initTransferPanel();
})();
